import logging
from typing import List, Optional
import os
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings

from config.settings import settings
from services.vector_db import VectorDBClient # Use the dedicated vector_db client

logger = logging.getLogger(__name__)

class RAGSystem:
    """Implements Retrieval Augmented Generation (RAG) for context retrieval."""

    def __init__(self, embedding_model: str = "models/embedding-001"):
        # The VectorDBClient internally handles embedding model and connection details
        # We initialize it here and use its methods for add/retrieve
        self.vector_db_client = VectorDBClient(embedding_model=embedding_model)
        logger.info("RAGSystem initialized using VectorDBClient.")

    def add_documents(self, texts: List[str], metadatas: Optional[List[dict]] = None, chunk_size: int = 1000, chunk_overlap: int = 200):
        """Adds new documents to the vectorstore."""
        if not texts:
            logger.warning("No texts provided to add to RAG system.")
            return
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        
        # Create Documents with text content and optional metadata
        docs_for_splitting = []
        for i, text in enumerate(texts):
            doc_metadata = metadatas[i] if metadatas and len(metadatas) > i else {}
            docs_for_splitting.append(Document(page_content=text, metadata=doc_metadata))
        splits = text_splitter.split_documents(docs_for_splitting)
        
        # Extract page_content and metadata from splits to pass to VectorDBClient
        split_texts = [s.page_content for s in splits]
        split_metadatas = [s.metadata for s in splits]
        try:
            self.vector_db_client.add_vectors(split_texts, split_metadatas)
            logger.info(f"Successfully added {len(splits)} document chunks to VectorDBClient.")
        except Exception as e:
            logger.error(f"Failed to add documents to RAG system: {e}", exc_info=True)
            raise
    def retrieve_documents(self, query: str, k: int = 4) -> List[Document]:
        """Retrieves relevant documents from the vectorstore based on a query."""
        if not query:
            logger.warning("Empty query provided for RAG retrieval. Returning empty list.")
            return []
        try:
            # VectorDBClient.search_vectors returns a list of dicts with 'text', 'score', 'payload'
            search_results = self.vector_db_client.search_vectors(query, limit=k)
            
            # Convert results back to Document objects for LangChain compatibility
            docs = [
                Document(page_content=res.get('text', ''), metadata=res.get('payload', {}))
                for res in search_results
            ]
            logger.info(f"Retrieved {len(docs)} documents for query: \'{query}\'")
            return docs
        except Exception as e:
            logger.error(f"Error retrieving documents from RAG system: {e}", exc_info=True)
            return []


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Example Usage
    rag_system = RAGSystem()

    # Add some sample documents
    sample_texts = [
        "Our company offers comprehensive freight forwarding services for ocean, air, and land transportation.",
        "For FCL shipments, we provide 20ft, 40ft, and 40ft HQ containers. Please specify your container requirements.",
        "LCL cargo is consolidated to optimize space and cost. We handle cargo by weight and volume.",
        "Air freight services are available for urgent shipments. Dimensions and weight are critical for air cargo calculations.",
        "We offer customs clearance services at both origin and destination ports.",
        "Incoterms define the responsibilities of buyers and sellers for the delivery of goods under sales contracts."
    ]
    print("\n--- Adding documents to RAG system ---")
    # No explicit metadatas for this simple example, but could be added
    rag_system.add_documents(sample_texts)

    # Retrieve documents
    print("\n--- Retrieving documents ---")
    query1 = "What kind of containers do you offer for full container load?"
    retrieved_docs1 = rag_system.retrieve_documents(query1)
    print(f"Query: \'{query1}\'")
    for i, doc in enumerate(retrieved_docs1):
        print(f"  Doc {i+1}: {doc.page_content}")

    query2 = "Do you handle customs?"
    retrieved_docs2 = rag_system.retrieve_documents(query2)
    print(f"\nQuery: \'{query2}\'")
    for i, doc in enumerate(retrieved_docs2):
        print(f"  Doc {i+1}: {doc.page_content}")

    query3 = "What about air cargo?"
    retrieved_docs3 = rag_system.retrieve_documents(query3)
    print(f"\nQuery: \'{query3}\'")
    for i, doc in enumerate(retrieved_docs3):
        print(f"  Doc {i+1}: {doc.page_content}")

    # Test with an empty query
    print("\n--- Testing with empty query ---")
    empty_query_docs = rag_system.retrieve_documents("")
    print(f"Empty query results: {empty_query_docs}")

    # Test with a non-existent query
    print("\n--- Testing with non-existent query ---")
    non_existent_query_docs = rag_system.retrieve_documents("quantum physics")
    print(f"Non-existent query results: {non_existent_query_docs}")