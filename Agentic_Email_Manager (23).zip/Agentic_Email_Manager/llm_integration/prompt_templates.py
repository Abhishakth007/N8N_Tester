from langchain_core.prompts import ChatPromptTemplate

CLASSIFICATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", "You are an expert email classifier. Your task is to determine if an email is a freight inquiry or not. Respond with 'FREIGHT_INQUIRY' if it is, and 'OTHER' if it is not."),
    ("human", "Email Subject: {subject}\nEmail Body: {body}\nIs this a freight inquiry?")
])
PORT_INFO = """
| Port Code | Port Name                        | City            | Country        |
|-----------|----------------------------------|------------------|----------------|
| INNSA     | Nhava Sheva (JNPT)               | Mumbai           | India          |
| INMAA     | Chennai Port                     | Chennai          | India          |
| INCCU     | Kolkata Port                     | Kolkata          | India          |
| INCOK     | Cochin Port                      | Kochi            | India          |
| INMUN     | Mundra Port                      | Mundra           | India          |
| USNYC     | Port of New York & New Jersey    | New York         | USA            |
| USLAX     | Port of Los Angeles              | Los Angeles      | USA            |
| USSFO     | Port of San Francisco            | San Francisco    | USA            |
| USMIA     | PortMiami                        | Miami            | USA            |
| USSEA     | Port of Seattle                  | Seattle          | USA            |
| CAVAN     | Port of Vancouver                | Vancouver        | Canada         |
| CAMTR     | Port of Montreal                 | Montreal         | Canada         |
| CATOR     | Port of Toronto                  | Toronto          | Canada         |
| CAHAL     | Port of Halifax                  | Halifax          | Canada         |
| NGAPP     | Port of Lagos (Apapa)            | Lagos            | Nigeria        |
| SACPT     | Port of Cape Town                | Cape Town        | South Africa   |
| SADUR     | Port of Durban                   | Durban           | South Africa   |
| TADAR     | Port of Dar es Salaam            | Dar es Salaam    | Tanzania       |
| EGALY     | Port of Alexandria               | Alexandria       | Egypt          |
"""


# --- Extraction Prompt ---
EXTRACTION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """
You are an expert freight logistics assistant. Your task is to extract structured freight inquiry data from the email content.
Leverage the provided RAG Context to resolve ambiguities, fill in missing details, or clarify industry-specific terms found in the email.
The output should strictly adhere to the provided JSON schema.

### Extracted Data Structure (JSON Schema):
{schema}

### Interpretation Rules:

- If any field is missing or uncertain -> set to `null`.
- **Weight Conversion**:
  - lbs -> kg = x 0.453592
  - tonnes -> kg = x 1000
  - US tons -> kg = x 907.18474
  - Metric tons/MT -> kg = x 1000
  - Convert any type of weight format into kg.
  - **Dimensions**:- Convert all dimensions to cm.
- **Date Handling**:
  - If only one date is mentioned for shipment, set it as both `shipment_date_range_from` and `shipment_date_range_to`.
  - Infer the current year if only month/day is provided (e.g., "July 20" implies "July 20, {Current Year}").
  - Date format should be "YYYY-MM-DD".
- **Port Code**: Always try to extract recognized port codes (e.g., "USNYC" for New York, "SGSIN" for Singapore) . Use {PORT_INFO} for the reference port names and port codes.Use city/country names if codes are not  Found in the {PORT_INFO}.
- **Cargo Type Mapping**: Map specific cargo descriptions to one of these categories: GENERAL/FAK (Freight Of All Kinds), PERISHABLE, SPECIAL, REEFER. Examples: "kitchenware" -> GENERAL, "food items" -> PERISHABLE, "machinery" -> SPECIAL, "frozen goods" -> REEFER. If unsure, default to GENERAL.
- **Container Type**: If container types are mentioned, ensure they match valid values: "20GP", "40GP", "40HQ", "45HQ", "20RF", "40RF", "20OT", "40OT", "20FR", "40FR", "20TK". If multiple are mentioned, include all in a list.


**Email:**
> "Hello, we need an LCL shipping quote for 8000 kg of perishable goods from Chennai to Los Angeles. Approximate dimensions per unit are 120x100x150 cm, 10 units total. Preferred shipment around July 20. Incoterm: CIF."

**Extracted JSON (conforming to schema):**json
{{
  "query_type": "OCEAN_LCL",
  "intent_resolution_stage": "Freight Enquiry",
  "extraction_status": "fully_extracted",
  "payload": {{
    "transport_mode_group": "LCL",
    "origin_port": ["INMAA"],
    "destination_port": ["USLAX"],
    "cargo_type": "PERISHABLE",
    "cargo_weight": 8000.0,
    "container_type": null,
    "cargo_unit_dimensions": {{
      "length": 120.0,
      "breadth": 100.0,
      "height": 150.0
    }},
    "no_of_units": 10,
    "shipment_date_range_from": "2025-07-20",
    "shipment_date_range_to": "2025-07-20",
    "incoterm": "CIF",
    "transportation_type": "EXPORT"
  }}
}}
Example (OCEAN_FCL):
Email:

"We require a quote for a 40ft HQ container from Miami to Seattle. Cargo is general, around 25 tons. Shipment is flexible, sometime in August."

Extracted JSON (conforming to schema):{{
  "query_type": "OCEAN_FCL",
  "intent_resolution_stage": "Freight Enquiry",
  "extraction_status": "partial",
  "missing_mandatory_fields": ["shipment_date_range_from", "shipment_date_range_to"],
  "payload": {{
    "transport_mode_group": "FCL",
    "origin_port": ["USMIA"],
    "destination_port": ["USSEA"],
    "cargo_type": "GENERAL",
    "cargo_weight": 25000.0,
    "container_type": ["40HQ"],
    "cargo_unit_dimensions": null,
    "no_of_units": null,
    "shipment_date_range_from": null,
    "shipment_date_range_to": null,
    "incoterm": null,
    "transportation_type": null
  }}
}}Return the result in this format — only these fields, set null where applicable.
"""),
("human", """
Current Email Subject: {email_subject}
Current Email Body:
{email_body}

Previous Conversation Context:
{previous_conversation_context}

RAG Context (if any):
{rag_context}
""")
])

VALIDATION_PROMPT = ChatPromptTemplate.from_messages([
("system", "You are a data validation expert. Review the extracted freight inquiry data against the original email. Identify any inconsistencies or missing critical information. Suggest corrections or additional questions to ask the customer. Respond in a structured JSON format indicating validity and suggested changes."),
("human", "Original Email: {original_email}\nExtracted Data: {extracted_data}\nValidation Report:")
])

RAG_QUERY_PROMPT = ChatPromptTemplate.from_messages([
("system", "You are a helpful assistant. Based on the user's email, generate a concise query to retrieve relevant information from a knowledge base that can help answer the inquiry."),
("human", "Email: {email_content}\nQuery:")
])

RESPONSE_GENERATION_PROMPT = ChatPromptTemplate.from_messages([
("system", """
You are a professional freight forwarding sales representative. Draft a polite and comprehensive email response to the customer based on the provided template and context.
Carefully review the `Conversation History` to understand the full context of the ongoing discussion, including previous questions, responses, and any information already provided by the customer.
Ensure the response is clear, concise, and directly addresses the customer's inquiry or request for missing information.
If a rate is provided, present it clearly. If information is missing, politely and clearly ask for the specific details needed.
Maintain a helpful, professional, and friendly tone.

Conversation History:
{conversation_history}

Template:
{template}

Context:
{context}

Draft Email Response:
""")
])