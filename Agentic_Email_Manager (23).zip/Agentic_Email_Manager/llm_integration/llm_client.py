import logging
from typing import Any, Dict, List, Optional

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_anthropic import ChatAnthropic # Added for Anthropic LLM
from langchain_core.messages import BaseMessage

from config.settings import settings

logger = logging.getLogger(__name__)

class LLMClient:
    """Unified client for interacting with various Large Language Models."""

    def __init__(self, model_name: str = "gemini-pro", provider: str = "google", temperature: Optional[float] = None):
        self.model_name = model_name
        self.provider = provider.lower()
        # Use provided temperature or fallback to settings.LLM_TEMPERATURE
        self.temperature = temperature if temperature is not None else settings.LLM_TEMPERATURE
        self.llm = self._initialize_llm()
        logger.info(f"LLMClient initialized with provider: {self.provider}, model: {self.model_name}, temperature: {self.temperature}")

    def _initialize_llm(self):
        """Initializes the appropriate LLM based on the provider."""
        if self.provider == "google":
            if not settings.GEMINI_API_KEY:
                logger.error("GEMINI_API_KEY not found in settings. Cannot initialize Google LLM.")
                raise ValueError("GEMINI_API_KEY is required for Google LLM provider.")
            return ChatGoogleGenerativeAI(model=self.model_name, google_api_key=settings.GEMINI_API_KEY, temperature=self.temperature)
        elif self.provider == "openai":
            if not settings.OPENAI_API_KEY:
                logger.error("OPENAI_API_KEY not found in settings. Cannot initialize OpenAI LLM.")
                raise ValueError("OPENAI_API_KEY is required for OpenAI LLM provider.")
            return ChatOpenAI(model=self.model_name, openai_api_key=settings.OPENAI_API_KEY, temperature=self.temperature)
        elif self.provider == "anthropic":
            if not settings.ANTHROPIC_API_KEY:
                logger.error("ANTHROPIC_API_KEY not found in settings. Cannot initialize Anthropic LLM.")
                raise ValueError("ANTHROPIC_API_KEY is required for Anthropic LLM provider.")
            return ChatAnthropic(model=self.model_name, anthropic_api_key=settings.ANTHROPIC_API_KEY, temperature=self.temperature)
        else:
            logger.error(f"Unsupported LLM provider: {self.provider}")
            raise ValueError(f"Unsupported LLM provider: {self.provider}")

    def invoke(self, prompt: Any, **kwargs) -> str:
        """Invokes the LLM with a given prompt and returns the string output."""
        try:
            response = self.llm.invoke(prompt, **kwargs)
            return str(response.content) if hasattr(response, 'content') else str(response)
        except Exception as e:
            logger.error(f"Error invoking LLM ({self.provider}/{self.model_name}): {e}", exc_info=True)
            raise

    def stream(self, prompt: Any, **kwargs):
        """Streams responses from the LLM."""
        try:
            for chunk in self.llm.stream(prompt, **kwargs):
                yield chunk
        except Exception as e:
            logger.error(f"Error streaming from LLM ({self.provider}/{self.model_name}): {e}", exc_info=True)
            raise

    def chat(self, messages: List[BaseMessage], **kwargs) -> str:
        """Sends a list of chat messages to the LLM and returns the string output."""
        try:
            response = self.llm.invoke(messages, **kwargs)
            return str(response.content) if hasattr(response, 'content') else str(response)
        except Exception as e:
            logger.error(f"Error in LLM chat ({self.provider}/{self.model_name}): {e}", exc_info=True)
            raise

    def with_structured_output(self, schema: Any):
        """Returns a new LLM instance configured for structured output."""
        # This creates a new chain specifically for structured output, maintaining temperature etc.
        return self.llm.with_structured_output(schema)