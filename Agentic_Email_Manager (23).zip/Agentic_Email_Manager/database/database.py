import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from typing import Optional, Any

logger = logging.getLogger(__name__)

class MongoDBClient:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(MongoDBClient, cls).__new__(cls)
            cls._instance._initialized = False  # Add an initialization flag
        return cls._instance

    def __init__(self, mongo_uri: str = "mongodb://localhost:27017/", db_name: str = "email_manager_db"):
        if not hasattr(self, "_initialized") or not self._initialized: # Ensure __init__ runs only once for singleton
            self.mongo_uri = mongo_uri
            self.db_name = db_name
            self.client: Optional[MongoClient] = None
            self.db: Optional[Any] = None
            self.conversations_collection: Optional[Any] = None
            self.freight_metadata_collection: Optional[Any] = None
            self._initialized = True
            self.connect()

    def close(self):
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed.")
            self.client = None
            self.db = None
            self.conversations_collection = None
            self.freight_metadata_collection = None

    def connect(self):
        try:
            self.client = MongoClient(self.mongo_uri)
            self.client.admin.command("ping")  # Test connection
            self._db = self.client[self.db_name] # Use _db here
            self.conversations_collection = self._db["conversations"]
            self.freight_metadata_collection = self._db["freight_metadata"]
            
            # --- Add Index Creation for improved threading lookup ---
            # Index on payload.references for freight_metadata collection
            self.freight_metadata_collection.create_index([("payload.references", 1)], name="payload_references_idx", background=True)
            logger.info("Ensured index on 'freight_metadata.payload.references'.")

            # Index on messages.message_id for conversations collection
            self.conversations_collection.create_index([("messages.message_id", 1)], name="messages_message_id_idx", background=True)
            logger.info("Ensured index on 'conversations.messages.message_id'.")
            # --- End Index Creation ---

            logger.info("Successfully connected to MongoDB.")
        except ConnectionFailure as e:
            logger.error(f"MongoDB connection failed: {e}", exc_info=True)
            self.client = None
            self.db = None
            self.conversations_collection = None
            self.freight_metadata_collection = None
        except Exception as e:
            logger.error(f"An unexpected error occurred during MongoDB connection: {e}", exc_info=True)
            self.client = None
            self.db = None
            self.conversations_collection = None
            self.freight_metadata_collection = None

    def get_db(self):
        if self.db is None:
            self.connect()
        return self.db

    def get_conversations_collection(self):
        if self.conversations_collection is None:
            self.connect()
        return self.conversations_collection

    def get_freight_metadata_collection(self):
        if self.freight_metadata_collection is None:
            self.connect()
        return self.freight_metadata_collection


mongodb_client = MongoDBClient() # Create a singleton instance

# Example of how to use it (for testing/demonstration)
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Test with default URI
    db_client = MongoDBClient()
    if db_client.get_db():
        logger.info("Database connection successful.")
        # You can now interact with collections, e.g., db_client.conversations_collection.find_one({})
    else:
        logger.error("Failed to connect to database.")

    # Test with a different URI (if needed)
    # db_client_custom = MongoDBClient(mongo_uri="mongodb://localhost:27018/", db_name="test_db")
    # if db_client_custom.get_db():
    #     logger.info("Custom database connection successful.")
    # else:
    #     logger.error("Failed to connect to custom database.")

    db_client.close()
    # db_client_custom.close()