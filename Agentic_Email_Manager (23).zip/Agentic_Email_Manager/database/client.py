import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
from typing import Optional, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class MongoDBClient:
    """A client for interacting with MongoDB, handling connections and basic CRUD operations."""

    def __init__(self, mongo_uri: str, db_name: str = "freight_email_db"):
        self._mongo_uri = mongo_uri
        self._db_name = db_name
        self._client: Optional[MongoClient] = None
        self._db: Optional[Any] = None
        self.conversations_collection: Optional[Any] = None
        self.freight_metadata_collection: Optional[Any] = None
        
    def get_collection(self , name):
        if self._db is None:
            raise ConnectionFailure("Database connection not established. Call connect() first.")
        return self._db[name]

    def connect(self):
        """Establishes a connection to the MongoDB server and initializes collections."""
        try:
            self._client = MongoClient(self._mongo_uri)
            self._client.admin.command("ping")  # Cheap way to verify connection
            self._db = self._client[self._db_name]
            self.conversations_collection = self._db["conversations"]
            self.freight_metadata_collection = self._db["freight_metadata"]
            logger.info(f"Connected to MongoDB at {self._mongo_uri}, database: {self._db_name}")
        except ConnectionFailure as e:
            logger.critical(f"MongoDB connection failed: {e}", exc_info=True)
            raise ConnectionFailure(
                f"Could not connect to MongoDB at {self._mongo_uri}. Ensure the server is running."
            ) from e
        except Exception as e:
            logger.critical(f"Unexpected error during MongoDB connection: {e}", exc_info=True)
            raise RuntimeError(f"Failed to connect to MongoDB: {e}") from e

    def close_connection(self):
        """Closes the MongoDB connection."""
        if self._client:
            self._client.close()
            logger.info("MongoDB connection closed.")

    def insert_one(self, collection_name: str, document: Dict[str, Any]) -> Optional[str]:
        """Inserts a single document into the specified collection."""
        if self._db is None:
            logger.error("Database connection not established. Cannot insert document.")
            return None
        try:
            collection = self._db[collection_name]
            result = collection.insert_one(document)
            logger.debug(f"Inserted document with ID: {result.inserted_id} into {collection_name}")
            return str(result.inserted_id)
        except OperationFailure as e:
            logger.error(f"MongoDB operation failed during insert_one into {collection_name}: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"Unexpected error during insert_one into {collection_name}: {e}", exc_info=True)
            return None

    def find_one(self, collection_name: str, query: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Finds a single document in the specified collection."""
        if self._db is None:
            logger.error("Database connection not established. Cannot find document.")
            return None
        try:
            collection = self._db[collection_name]
            document = collection.find_one(query)
            if document:
                logger.debug(f"Found document in {collection_name} with query {query}")
            else:
                logger.debug(f"No document found in {collection_name} with query {query}")
            return document
        except OperationFailure as e:
            logger.error(f"MongoDB operation failed during find_one from {collection_name}: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"Unexpected error during find_one from {collection_name}: {e}", exc_info=True)
            return None

    def update_one(self, collection_name: str, query: Dict[str, Any], update: Dict[str, Any]) -> bool:
        """Updates a single document in the specified collection."""
        if self._db is None:
            logger.error("Database connection not established. Cannot update document.")
            return False
        try:
            collection = self._db[collection_name]
            result = collection.update_one(query, {"$set": update})
            if result.matched_count > 0:
                logger.debug(f"Updated {result.matched_count} document(s) in {collection_name} with query {query}")
                return True
            else:
                logger.debug(f"No document matched for update in {collection_name} with query {query}")
                return False
        except OperationFailure as e:
            logger.error(f"MongoDB operation failed during update_one in {collection_name}: {e}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"Unexpected error during update_one in {collection_name}: {e}", exc_info=True)
            return False

    def delete_many(self, collection_name: str, query: Dict[str, Any]) -> int:
        """Deletes multiple documents from the specified collection."""
        if self._db is None:
            logger.error("Database connection not established. Cannot delete documents.")
            return 0
        try:
            collection = self._db[collection_name]
            result = collection.delete_many(query)
            logger.debug(f"Deleted {result.deleted_count} document(s) from {collection_name} with query {query}")
            return result.deleted_count
        except OperationFailure as e:
            logger.error(f"MongoDB operation failed during delete_many from {collection_name}: {e}", exc_info=True)
            return 0
        except Exception as e:
            logger.error(f"Unexpected error during delete_many from {collection_name}: {e}", exc_info=True)
            return 0


# No longer using __main__ block for client.py as it's replaced by database.py singleton
# and explicit initialization in main.py for testing purposes.
# The singleton logic is now handled in database.py