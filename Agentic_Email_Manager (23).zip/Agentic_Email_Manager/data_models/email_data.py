from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional
from datetime import datetime


class EmailMessage(BaseModel):
    message_id: str
    subject: Optional[str] = None
    sender: Optional[EmailStr] = None
    recipients: List[EmailStr] = Field(default_factory=list)
    cc: List[EmailStr] = Field(default_factory=list)
    bcc: List[EmailStr] = Field(default_factory=list)
    body: Optional[str] = None
    html_body: Optional[str] = None
    timestamp: Optional[datetime] = None # Deprecated, use received_at/sent_at
    in_reply_to: Optional[str] = None
    references: Optional[List[str]] = Field(default_factory=list)

    received_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    direction: Optional[str] = None  # "inbound" | "outbound"
    uid: Optional[int] = None # For IMAP UID

    conversation_id: Optional[str] = None # Link to a conversation thread
    intent_resolution_stage: Optional[str] = None # Classification result for this email


class EmailThread(BaseModel):
    # Core fields for the conversation document in the 'conversations' collection
    conversation_id: str
    participants: List[EmailStr] = Field(default_factory=list)
    channel: str = "Email"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    
    # Store all messages in the thread
    messages: List[EmailMessage] = Field(default_factory=list)
    
    # Summary of the conversation (newly added)
    conversation_summary: Optional[str] = None 

    # Status of the conversation (e.g., "new", "active", "resolved", "pending_response")
    status: Optional[str] = "new" 
    
    # Index for quick lookup of messages by ID within the thread (optional, can be derived)
    message_id_index: Optional[dict] = Field(default_factory=dict) 
    
    # Normalized subject for easier grouping/display
    normalized_subject: Optional[str] = None 
    
    # The most recent message in the thread
    latest_message: Optional[EmailMessage] = None