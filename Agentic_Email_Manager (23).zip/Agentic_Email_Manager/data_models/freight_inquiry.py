from .common import InquiryType, CargoType, TransportationType, Incoterm
from pydantic import BaseModel, Field, field_validator, ValidationInfo, model_validator
from typing import Optional, List, Literal, Dict, Any
from datetime import datetime, date, timedelta, timezone

class CargoUnitDimensions(BaseModel):
    length: Optional[float] = None
    breadth: Optional[float] = None
    height: Optional[float] = None

class FreightPayload(BaseModel):
    origin_port: Optional[List[Optional[str]]] = None
    destination_port: Optional[List[Optional[str]]] = None
    cargo_type: Optional[CargoType] = None
    cargo_weight: Optional[float] = None
    container_type: Optional[List[str]] = None
    cargo_unit_dimensions: Optional[CargoUnitDimensions] = None
    no_of_units: Optional[int] = None
    shipment_date_range_from: Optional[datetime] = None
    shipment_date_range_to: Optional[datetime] = None
    incoterm: Optional[Incoterm] = None
    transportation_type: Optional[TransportationType] = None
    enriched_details: Optional[Dict[str, Any]] = Field(None, description="Container for enriched data from lookups")

    @field_validator("destination_port", mode="before")
    @classmethod
    def clean_destination_port(cls, v):
        if isinstance(v, list):
            return [item for item in v if item is not None]
        return v

    @field_validator("origin_port", mode="before")
    @classmethod
    def clean_origin_port(cls, v):
        if isinstance(v, list):
            return [item for item in v if item is not None]
        return v

class FreightMetadata(BaseModel):
    conversation_id: str
    query_type: Optional[InquiryType] = None
    intent_resolution_stage: Optional[str] = None
    extraction_status: Literal["partial", "fully_extracted", "fully_extracted_with_rate", "fully_extracted_without_rate"] = "partial"
    missing_mandatory_fields: List[str] = Field(default_factory=list)
    missing_mandatory_fields_temp: Optional[List[str]] = Field(default=None, exclude=True)
    payload: Optional[FreightPayload] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    is_active: bool = True
    last_inbound_message_id: Optional[str] = None

    @field_validator("expires_at", mode="before")
    def set_expiry(cls, v: Optional[datetime], info: ValidationInfo) -> Optional[datetime]:
        if v is None and "created_at" in info.data and info.data["created_at"] is not None:
            created_at_dt = info.data["created_at"]
            if isinstance(created_at_dt, date) and not isinstance(created_at_dt, datetime):
                created_at_dt = datetime(created_at_dt.year, created_at_dt.month, created_at_dt.day)
            if created_at_dt.tzinfo is None:
                created_at_dt = created_at_dt.replace(tzinfo=timezone.utc)
            return created_at_dt + timedelta(days=7)
        return v

    @field_validator("is_active", mode="before")
    def check_active(cls, v: bool, info: ValidationInfo) -> bool:
        expires_at_dt = info.data.get("expires_at")
        if expires_at_dt is not None:
            if expires_at_dt.tzinfo is None:
                expires_at_dt = expires_at_dt.replace(tzinfo=timezone.utc)
            if expires_at_dt < datetime.now(timezone.utc):
                return False
        return v

    @field_validator("payload", mode="after")
    def validate_payload_fields(cls, payload: Optional[FreightPayload], info: ValidationInfo) -> Optional[FreightPayload]:
        missing = []

        if payload is None:
            missing.append("payload_data_missing")
        else:
            query_type = info.data.get("query_type")
            if isinstance(query_type, str):
                try:
                    query_type = InquiryType(query_type)
                except ValueError:
                    query_type = None

            if query_type == InquiryType.AIR or query_type == InquiryType.OCEAN_LCL:
                if (payload.cargo_unit_dimensions is None or
                    not all(dim is not None for dim in [
                        payload.cargo_unit_dimensions.length,
                        payload.cargo_unit_dimensions.breadth,
                        payload.cargo_unit_dimensions.height])):
                    missing.append("cargo_unit_dimensions (lxbxh)")
                if payload.no_of_units is None:
                    missing.append("no_of_units")

            elif query_type == InquiryType.OCEAN_FCL:
                if not payload.container_type:
                    missing.append("container_type (Mandatory For FCL Queries)")

            if not payload.origin_port:
                missing.append("origin_port")
            if not payload.destination_port:
                missing.append("destination_port")
            if payload.shipment_date_range_from is None:
                missing.append("shipment_date_range_from")
            if payload.shipment_date_range_to is None:
                missing.append("shipment_date_range_to")
            if payload.cargo_weight is None:
                missing.append("cargo_weight")
            if payload.cargo_type is None:
                missing.append("cargo_type")

        info.data["missing_mandatory_fields_temp"] = missing
        return payload

    @model_validator(mode="after")
    def set_extraction_status(self) -> 'FreightMetadata':
        if self.missing_mandatory_fields_temp:
            self.missing_mandatory_fields = self.missing_mandatory_fields_temp
        else:
            self.missing_mandatory_fields = []

        if self.missing_mandatory_fields:
            self.extraction_status = "partial"
        else:
            self.extraction_status = "fully_extracted"

        if self.extraction_status == "fully_extracted" and self.payload and self.payload.enriched_details:
            if self.payload.enriched_details.get("calculatedRate") and self.payload.enriched_details.get("calculatedRate") != "N/A":
                self.extraction_status = "fully_extracted_with_rate"
            else:
                self.extraction_status = "fully_extracted_without_rate"

        return self
