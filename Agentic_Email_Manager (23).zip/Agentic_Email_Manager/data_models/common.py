from enum import Enum
from pydantic import BaseModel, Field
from typing import Optional

class InquiryType(str, Enum):
    OCEAN_FCL = "OCEAN_FCL"
    OCEAN_LCL = "OCEAN_LCL"
    AIR = "AIR"

class CargoType(str, Enum):
    GENERAL = "GENERAL"
    PERISHABLE = "PERISHABLE"
    SPECIAL = "SPECIAL"
    REEFER = "REEFER"
    FAK = "GENERAL/FAK"

class TransportationType(str, Enum):
    IMPORT = "IMPORT"
    EXPORT = "EXPORT"

class Incoterm(str, Enum):
    FOB = "FOB"
    CIF = "CIF"
    EXW = "EXW"
    DDP = "DDP"