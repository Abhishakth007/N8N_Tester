import logging
from typing import List, Tuple , Optional

from fuzzywuzzy import fuzz, process

logger = logging.getLogger(__name__)

class FuzzyMatching:
    """Utility class for fuzzy string matching operations."""

    @staticmethod
    def simple_ratio(s1: str, s2: str) -> int:
        """Calculates the simple ratio similarity between two strings.

        Args:
            s1: The first string.
            s2: The second string.

        Returns:
            An integer representing the similarity score (0-100).
        """
        if not s1 or not s2:
            return 0
        return fuzz.ratio(s1, s2)

    @staticmethod
    def partial_ratio(s1: str, s2: str) -> int:
        """Calculates the partial ratio similarity between two strings.
        Useful when one string is a substring of another.

        Args:
            s1: The first string.
            s2: The second string.

        Returns:
            An integer representing the similarity score (0-100).
        """
        if not s1 or not s2:
            return 0
        return fuzz.partial_ratio(s1, s2)

    @staticmethod
    def token_sort_ratio(s1: str, s2: str) -> int:
        """Calculates the token sort ratio similarity between two strings.
        Ignores word order and extra whitespace.

        Args:
            s1: The first string.
            s2: The second string.

        Returns:
            An integer representing the similarity score (0-100).
        """
        if not s1 or not s2:
            return 0
        return fuzz.token_sort_ratio(s1, s2)

    @staticmethod
    def token_set_ratio(s1: str, s2: str) -> int:
        """Calculates the token set ratio similarity between two strings.
        Ignores duplicate words and word order.

        Args:
            s1: The first string.
            s2: The second string.

        Returns:
            An integer representing the similarity score (0-100).
        """
        if not s1 or not s2:
            return 0
        return fuzz.token_set_ratio(s1, s2)

    @staticmethod
    def extract_one(query: str, choices: List[str], scorer=fuzz.ratio) -> Optional[Tuple[str, int]]:
        """Finds the best match for a query string from a list of choices.

        Args:
            query: The string to match.
            choices: A list of strings to search within.
            scorer: The fuzzywuzzy scorer function to use (e.g., fuzz.ratio, fuzz.partial_ratio).

        Returns:
            A tuple containing the best matching string and its score, or None if no choices.
        """
        if not query or not choices:
            return None
        result = process.extractOne(query, choices, scorer=scorer)
        if result:
            return (result[0], result[1])
        return None

    @staticmethod
    def extract_top_n(query: str, choices: List[str], limit: int = 5, scorer=fuzz.ratio) -> List[Tuple[str, int]]:
        """Finds the top N best matches for a query string from a list of choices.

        Args:
            query: The string to match.
            choices: A list of strings to search within.
            limit: The maximum number of matches to return.
            scorer: The fuzzywuzzy scorer function to use.

        Returns:
            A list of tuples, each containing a matching string and its score.
        """
        if not query or not choices:
            return []
        results = process.extract(query, choices, limit=limit, scorer=scorer)
        return [(res[0], res[1]) for res in results]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    print("--- Testing FuzzyMatching ---")

    s1 = "apple inc"
    s2 = "Apple Inc."
    s3 = "apple corporation"
    s4 = "inc apple"

    print(f"\nSimple Ratio between \'{s1}\' and \'{s2}\': {FuzzyMatching.simple_ratio(s1, s2)}")
    print(f"Partial Ratio between \'{s1}\' and \'{s3}\': {FuzzyMatching.partial_ratio(s1, s3)}")
    print(f"Token Sort Ratio between \'{s1}\' and \'{s4}\': {FuzzyMatching.token_sort_ratio(s1, s4)}")
    print(f"Token Set Ratio between \'{s1}\' and \'{s4}\': {FuzzyMatching.token_set_ratio(s1, s4)}")

    choices = ["apple inc", "google llc", "microsoft corp", "amazon.com"]
    query = "Apple Incorporated"

    print(f"\nBest match for \'{query}\' in {choices}: {FuzzyMatching.extract_one(query, choices)}")
    print(f"Best match (token sort) for \'{query}\' in {choices}: {FuzzyMatching.extract_one(query, choices, scorer=fuzz.token_sort_ratio)}")

    query_partial = "microsoft"
    print(f"\nTop 2 matches (partial) for \'{query_partial}\' in {choices}: {FuzzyMatching.extract_top_n(query_partial, choices, limit=2, scorer=fuzz.partial_ratio)}")