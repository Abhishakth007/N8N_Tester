import logging
import os

def setup_logging():
    """Configures the application-wide logging."""
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    numeric_log_level = getattr(logging, log_level, None)
    if not isinstance(numeric_log_level, int):
        raise ValueError(f"Invalid log level: {log_level}")

    logging.basicConfig(
        level=numeric_log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler() # Log to console
            # Add FileHandler for logging to a file in production
            # logging.FileHandler("app.log")
        ]
    )
    logging.getLogger("httpx").setLevel(logging.WARNING) # Suppress noisy http client logs
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.info("Logging configured successfully.")

if __name__ == "__main__":
    # Example usage:
    setup_logging()
    logger = logging.getLogger(__name__)
    logger.debug("This is a debug message.")
    logger.info("This is an info message.")
    logger.warning("This is a warning message.")
    logger.error("This is an error message.")
    logger.critical("This is a critical message.")

    # Test with different log level
    os.environ["LOG_LEVEL"] = "DEBUG"
    print("\n--- Reconfiguring logging to DEBUG ---")
    setup_logging()
    logger.debug("This debug message should now be visible.")
    logger.info("This info message should also be visible.")