import logging
from datetime import datetime, date
from typing import Optional

import pendulum

logger = logging.getLogger(__name__)

class DateUtils:
    """Utility class for date parsing, formatting, and standardization."""

    @staticmethod
    def parse_date(date_string: str, formats: Optional[list[str]] = None) -> Optional[date]:
        """Parses a date string into a date object using a list of possible formats.

        Args:
            date_string: The string to parse.
            formats: A list of date format strings (e.g., ["YYYY-MM-DD", "MM/DD/YYYY"]).
                     If None, attempts to parse using common formats.

        Returns:
            A date object if parsing is successful, otherwise None.
        """
        if not date_string:
            return None

        if formats is None:
            # Common formats to try if not specified
            formats = [
                "YYYY-MM-DD", "MM/DD/YYYY", "DD-MM-YYYY", "YYYY/MM/DD",
                "MM-DD-YYYY", "DD/MM/YYYY", "YYYY.MM.DD", "MM.DD.YYYY",
                "DD.MM.YYYY", "YYYYMMDD", "MMDDYYYY", "DDMMYYYY",
                "MMM DD, YYYY", "DD MMM YYYY", "MMMM DD, YYYY", "DD MMMM YYYY"
            ]

        for fmt in formats:
            try:
                dt = pendulum.from_format(date_string, fmt)
                return dt.date()
            except Exception:
                continue
        logger.warning(f"Could not parse date string \'{date_string}\' with provided formats.")
        return None

    @staticmethod
    def format_date(date_obj: date, fmt: str = "YYYY-MM-DD") -> str:
        """Formats a date object into a string.

        Args:
            date_obj: The date object to format.
            fmt: The desired format string (e.g., "YYYY-MM-DD").

        Returns:
            A formatted date string.
        """
        if not date_obj:
            return ""
        return pendulum.parse(str(date_obj)).format(fmt)

    @staticmethod
    def get_current_date() -> date:
        """Returns the current UTC date."""
        return pendulum.now("UTC").date()

    @staticmethod
    def days_between(start_date: date, end_date: date) -> int:
        """Calculates the number of days between two dates."""
        return (end_date - start_date).days


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    print("--- Testing DateUtils ---")

    # Test parse_date
    print("\nParsing Dates:")
    print(f"2025-07-03: {DateUtils.parse_date("2025-07-03")}")
    print(f"07/03/2025: {DateUtils.parse_date("07/03/2025")}")
    print(f"03-JUL-2025: {DateUtils.parse_date("03-JUL-2025", formats=["DD-MMM-YYYY"])}")
    print(f"July 3, 2025: {DateUtils.parse_date("July 3, 2025")}")
    print(f"Invalid Date: {DateUtils.parse_date("Not a date")}")

    # Test format_date
    print("\nFormatting Dates:")
    today = DateUtils.get_current_date()
    print(f"Today ({today}) formatted as MM/DD/YYYY: {DateUtils.format_date(today, "MM/DD/YYYY")}")
    print(f"Today ({today}) formatted as DD-MM-YYYY: {DateUtils.format_date(today, "DD-MM-YYYY")}")

    # Test get_current_date
    print("\nCurrent Date:")
    print(f"Current UTC Date: {DateUtils.get_current_date()}")

    # Test days_between
    print("\nDays Between Dates:")
    date1 = DateUtils.parse_date("2025-01-01")
    date2 = DateUtils.parse_date("2025-01-31")
    if date1 and date2:
        print(f"Days between {date1} and {date2}: {DateUtils.days_between(date1, date2)}")

    date3 = DateUtils.parse_date("2025-07-01")
    date4 = DateUtils.parse_date("2025-06-01")
    if date3 and date4:
        print(f"Days between {date3} and {date4}: {DateUtils.days_between(date3, date4)}")