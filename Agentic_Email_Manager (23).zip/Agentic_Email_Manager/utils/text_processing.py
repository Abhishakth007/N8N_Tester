import re
from bs4 import BeautifulSoup

class TextProcessor:
    """Utility class for text cleaning and processing."""

    @staticmethod
    def clean_html(html_content: str) -> str:
        """Removes HTML tags from a string and returns plain text."""
        if not html_content:
            return ""
        soup = BeautifulSoup(html_content, "html.parser")
        return soup.get_text(separator='\n')

    @staticmethod
    def normalize_whitespace(text: str) -> str:
        """Replaces multiple whitespace characters with a single space and strips leading/trailing whitespace."""
        if not text:
            return ""
        return re.sub(r'\s+', ' ', text).strip()

    @staticmethod
    def extract_urls(text: str) -> list[str]:
        """Extracts URLs from a given text."""
        if not text:
            return []
        # Basic regex for URL extraction. Can be made more robust if needed.
        urls = re.findall(r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+\S*', text)
        return urls

    @staticmethod
    def remove_quotes(text: str) -> str:
        """Removes common email reply/forward quotes from the text."""
        if not text:
            return ""
        # This is a simplified approach. More robust solutions might involve email parsing libraries.
        # Remove lines starting with ">", common in quoted replies
        lines = text.splitlines()
        cleaned_lines = [line for line in lines if not line.strip().startswith('>')] # Fixed: removed extra newlines and made it a raw string
        # Remove common reply headers (e.g., '--- Original Message ---', 'From: ... Sent: ...')
        cleaned_text = re.sub(r'^\s*----- Original Message -----\s*$', '',
            re.sub(r'^\s*From: .*\s*Sent: .*\s*To: .*\s*Subject: .*\s*$', '',
                '\n'.join(cleaned_lines), flags=re.MULTILINE | re.IGNORECASE
            ), flags=re.MULTILINE
        )
        return cleaned_text.strip()


if __name__ == "__main__":
    print("--- Testing TextProcessor ---")

    html_example = "<p>Hello <b>World</b>!</p><br><span>This is a test.</span>"
    print(f"Original HTML: {html_example}")
    print(f"Cleaned HTML: {TextProcessor.clean_html(html_example)}")

    whitespace_example = "  Hello   World!\nThis is a test.  "
    print(f"Original Whitespace: \n\'{whitespace_example}\'\n")
    print(f"Normalized Whitespace: \n\'{TextProcessor.normalize_whitespace(whitespace_example)}\'\n")

    url_example = "Visit our website at https://www.example.com or check out http://test.org/path?query=1. Also ftp://old.site is here."
    print(f"Original Text with URLs: {url_example}")
    print(f"Extracted URLs: {TextProcessor.extract_urls(url_example)}")

    quote_example = """
Hello team,

Please see below.

> On Mon, Jul 1, 2024 at 10:00 AM Original Sender <original@example.com> wrote:
> Subject: Old Subject
> To: Recipient <recipient@example.com>
> 
> This is the original message.

Thanks,
New Sender
"""
    print(f"Original Text with Quotes:\n{quote_example}")
    print(f"Cleaned Text (Quotes Removed):\n{TextProcessor.remove_quotes(quote_example)}")

    html_with_quotes = """
    <div>
        <p>Hi,</p>
        <p>See my reply:</p>
        <blockquote>
            <p>Original message content.</p>
        </blockquote>
    </div>
    """
    print(f"\nOriginal HTML with Quotes:\n{html_with_quotes}")
    cleaned_html_then_quotes = TextProcessor.remove_quotes(TextProcessor.clean_html(html_with_quotes))
    print(f"Cleaned HTML then Quotes Removed:\n{cleaned_html_then_quotes}")