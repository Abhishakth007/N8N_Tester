import logging
from datetime import datetime
from typing import Optional, List

from email_sending.smtp_client import SMTPClient
from data_models.email_data import EmailMessage
from email_processing.context_manager import ContextManager

logger = logging.getLogger(__name__)

class EmailSendingService:
    def __init__(self, context_manager: ContextManager):
        self._client = SMTPClient()
        self._context_manager = context_manager
        self._connected = False
        logger.info("EmailSendingService initialized with client type: SMTP")

    def connect(self):
        if not self._connected:
            self._client.connect()
            self._connected = True
            logger.info("Email sending client (SMTP) connected.")

    def disconnect(self):
        if self._connected:
            self._client.disconnect()
            self._connected = False
            logger.info("Email sending client (SMTP) disconnected.")

    def send_email(
        self,
        to_address: str,
        subject: str,
        plain_body: str,
        html_body: Optional[str] = None,
        from_address: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        in_reply_to_message_id: Optional[str] = None,
        references_message_ids: Optional[List[str]] = None,
        conversation_id: Optional[str] = None
    ) -> Optional[EmailMessage]:
        try:
            if not conversation_id:
                logger.error("conversation_id is required but was not provided.")
                return None

            effective_subject = subject
            effective_in_reply_to = in_reply_to_message_id
            effective_references = references_message_ids or []
            custom_headers = {"X-Conversation-ID": conversation_id}

            # Get latest thread info
            latest_thread_info = self._context_manager.get_latest_message_info(conversation_id)
            if latest_thread_info:
                effective_in_reply_to = latest_thread_info.get("message_id", effective_in_reply_to)                
                effective_references = list(set((latest_thread_info.get("references", []) or []) + ([effective_in_reply_to] if effective_in_reply_to else [])))                
                if effective_subject and not effective_subject.lower().startswith("re:"):
                    effective_subject = f"Re: {effective_subject}"

            # Send via SMTP
            response = self._client.send_email(
                to_address=to_address,
                subject=effective_subject,
                plain_body=plain_body,
                html_body=html_body,
                from_address=from_address,
                attachments=attachments,
                in_reply_to_message_id=effective_in_reply_to,
                references_message_ids=effective_references,
                custom_headers=custom_headers
            )

            if not isinstance(response, dict) or "message_id" not in response:
                logger.error("SMTP response missing 'message_id'. Expected dict with 'message_id' key.")
                return None

            message_id_sent = response["message_id"].strip("<>")

            outbound_email_message = EmailMessage(
                sender=from_address or self._client.smtp_username,
                recipients=[to_address],
                subject=effective_subject,
                body=plain_body,
                html_body=html_body,
                received_at=datetime.utcnow(),
                direction="outbound",
                message_id=message_id_sent,
                in_reply_to=effective_in_reply_to,
                references=effective_references,
                conversation_id=conversation_id
            )

            # Safely update DB
            try:
                self._context_manager.update_references_in_metadata(
                    conversation_id=conversation_id,
                    new_message_id=message_id_sent,
                    new_references=effective_references
                )
                self._context_manager.update_conversation_thread(
                    conversation_id=conversation_id,
                    new_email_message=outbound_email_message
                )
                logger.info(f"Outbound email recorded in conversation {conversation_id}.")
            except Exception as db_err:
                logger.error(f"Failed to update metadata/thread after sending email: {db_err}", exc_info=True)

            return outbound_email_message

        except Exception as e:
            logger.error(f"Failed to send email to {to_address}: {e}", exc_info=True)
            return None

