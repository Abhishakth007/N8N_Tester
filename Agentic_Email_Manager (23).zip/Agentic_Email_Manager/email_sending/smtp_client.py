# Agentic_Email_Manager/email_sending/smtp_client.py
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.utils import make_msgid
import logging
from typing import List, Optional, Dict, Any
import os

from config.settings import settings

logger = logging.getLogger(__name__)

class SMTPClient:
    def __init__(self):
        self.smtp_server = settings.SMTP_SERVER
        self.smtp_port = settings.SMTP_PORT
        self.smtp_username = settings.SMTP_USERNAME
        self.smtp_password = settings.SMTP_PASSWORD
        self.smtp_use_tls = settings.SMTP_USE_TLS
        self.client = None
        logger.info("SMTPClient initialized.")

    def connect(self):
        if self.client:
            return
        try:
            if self.smtp_use_tls:
                self.client = smtplib.SMTP(self.smtp_server, self.smtp_port)
                self.client.starttls()
            else:
                self.client = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
            self.client.login(self.smtp_username, self.smtp_password)
            logger.info("SMTP Connected Successfully.")
        except Exception as e:
            logger.error(f"SMTP Connection error: {e}", exc_info=True)
            self.client = None
            raise

    def disconnect(self):
        if self.client:
            try:
                self.client.quit()
                logger.info("SMTP Disconnected.")
            except Exception as e:
                logger.warning(f"Error disconnecting from SMTP: {e}")
            finally:
                self.client = None

    def send_email(
        self,
        to_address: str,
        subject: str,
        plain_body: Optional[str] = None,
        html_body: Optional[str] = None,
        from_address: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        in_reply_to_message_id: Optional[str] = None,
        references_message_ids: Optional[List[str]] = None,
        custom_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["To"] = to_address
            msg["From"] = from_address or self.smtp_username

            # Generate a message ID
            generated_message_id = make_msgid()
            msg["Message-ID"] = generated_message_id

            if in_reply_to_message_id:
                msg["In-Reply-To"] = in_reply_to_message_id
            if references_message_ids:
                msg["References"] = " ".join(references_message_ids)
            if custom_headers:
                for key, value in custom_headers.items():
                    msg[key] = value

            if plain_body:
                msg.attach(MIMEText(plain_body, "plain"))
            elif html_body:
                msg.attach(MIMEText(html_body, "html"))
            else:
                logger.warning("Sending email with no body. Attaching fallback empty plain body.")
                msg.attach(MIMEText("(No content)", "plain"))

            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(self.smtp_server, self.smtp_port, context=context) as server:
                server.login(self.smtp_username, self.smtp_password)
                server.sendmail(msg["From"], [to_address], msg.as_string())

            logger.info(f"Email sent successfully to {to_address} with subject '{subject}'")
            return {"message_id": generated_message_id.strip("<>")}  # Return without angle brackets for internal consistency

        except Exception as e:
            logger.error(f"Failed to send email to {to_address}: {e}", exc_info=True)
            return {}



