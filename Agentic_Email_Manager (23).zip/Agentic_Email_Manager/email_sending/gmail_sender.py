# Agentic_Email_Manager/email_sending/gmail_sender.py
import logging
from typing import List, Optional, Dict, Any
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import os
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

from config.settings import settings

logger = logging.getLogger(__name__)

# If modifying these scopes, ensure they are also updated in email_ingestion/gmail_client.py
SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

class GmailSender:
    """Handles sending emails via Gmail API."""

    def __init__(self):
        self.service = self._authenticate_gmail()
        logger.info("GmailSender initialized.")

    def _authenticate_gmail(self):
        """Authenticates with Gmail API using OAuth 2.0."""
        creds = None
        # The file token.json stores the user\"s access and refresh tokens, and is
        # created automatically when the authorization flow completes for the first
        # time. This token might be shared with gmail_client.py
        if os.path.exists("token.json"):
            creds = Credentials.from_authorized_user_file("token.json", SCOPES)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                # Ensure credentials.json is present for the InstalledAppFlow
                if not os.path.exists("credentials.json"):
                    logger.critical("credentials.json not found. Please download it from Google Cloud Console.")
                    raise FileNotFoundError("credentials.json is required for Gmail API authentication.")

                flow = InstalledAppFlow.from_client_secrets_file(
                    "credentials.json", SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open("token.json", "w") as token: # type: ignore
                token.write(creds.to_json())

        try:
            return build("gmail", "v1", credentials=creds)
        except HttpError as error:
            logger.error(f"An error occurred during Gmail API build: {error}")
            raise

    def send_email(
        self,
        to_address: str,
        subject: str,
        plain_body: str,
        html_body: Optional[str] = None,
        from_address: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        in_reply_to_message_id: Optional[str] = None,
        references_message_ids: Optional[List[str]] = None,
        user_id: str = "me"
    ) -> Dict[str, Any]:
        """Sends an email using the Gmail API."""
        try:
            message = MIMEMultipart("alternative") if html_body else MIMEMultipart()
            message["to"] = to_address
            message["from"] = from_address if from_address else user_id # "me" or actual email address
            message["subject"] = subject

            if in_reply_to_message_id:
                message["In-Reply-To"] = in_reply_to_message_id
            if references_message_ids:
                message["References"] = " ".join(references_message_ids)

            message.attach(MIMEText(plain_body, "plain"))
            if html_body:
                message.attach(MIMEText(html_body, "html"))

            if attachments:
                for file_path in attachments:
                    try:
                        with open(file_path, "rb") as attachment_file:
                            part = MIMEBase("application", "octet-stream")
                            part.set_payload(attachment_file.read())
                        encoders.encode_base64(part)
                        part.add_header(
                            "Content-Disposition",
                            f"attachment; filename= {os.path.basename(file_path)}",
                        )
                        message.attach(part)
                    except FileNotFoundError:
                        logger.warning(f"Attachment file not found: {file_path}")
                    except Exception as e:
                        logger.error(f"Error attaching file {file_path}: {e}", exc_info=True)

            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            send_message = {"raw": raw_message}

            sent_message = self.service.users().messages().send(userId=user_id, body=send_message).execute()
            logger.info(f"Message Id: {sent_message.get('id')} sent successfully to {to_address}")
            return sent_message
        except HttpError as error:
            logger.error(f"An error occurred while sending email via Gmail: {error}")
            raise
        except Exception as e:
            logger.error(f"An unexpected error occurred in GmailSender.send_email: {e}", exc_info=True)
            raise