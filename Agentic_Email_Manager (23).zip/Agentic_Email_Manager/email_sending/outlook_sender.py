# Agentic_Email_Manager/email_sending/outlook_sender.py
import logging
from typing import List, Optional, Dict, Any
import requests
import msal
import os
import base64

from config.settings import settings

logger = logging.getLogger(__name__)

# Microsoft Graph API scopes for sending mail
# Ensure these are configured in your Azure AD application registration
SCOPES = ["https://graph.microsoft.com/.default"]

class OutlookSender:
    """Handles sending emails via Microsoft Graph API (Outlook)."""

    def __init__(self):
        self.client_id = os.getenv("OUTLOOK_CLIENT_ID")
        self.client_secret = os.getenv("OUTLOOK_CLIENT_SECRET")
        self.tenant_id = os.getenv("OUTLOOK_TENANT_ID")
        self.authority = f"https://login.microsoftonline.com/{self.tenant_id}"
        self.app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=self.authority,
            client_credential=self.client_secret
        )
        self.access_token = self._acquire_token()
        logger.info("OutlookSender initialized.")

    def _acquire_token(self) -> str:
        """Acquires an access token for Microsoft Graph API."""
        result = self.app.acquire_token_for_client(scopes=SCOPES)
        if "access_token" in result:
            return result["access_token"]
        else:
            error_desc = result.get("error_description", "No error description provided")
            logger.error(f"Failed to acquire token: {error_desc}")
            raise Exception("Could not acquire access token for Outlook API.")

    def send_email(
        self,
        to_address: str,
        subject: str,
        plain_body: str, # Changed from body to plain_body for consistency
        html_body: Optional[str] = None, # Added html_body
        from_address: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        in_reply_to_message_id: Optional[str] = None, # Added for threading
        references_message_ids: Optional[List[str]] = None # Added for threading
    ) -> Dict[str, Any]:
        """Sends an email using the Microsoft Graph API."""
        if not self.access_token:
            self._acquire_token() # Try to re-acquire if token is missing or expired

        send_mail_url = f"https://graph.microsoft.com/v1.0/users/{from_address if from_address else settings.EMAIL_ACCOUNT}/sendMail"

        message_payload = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": "Html" if html_body else "Text", # Use Html if html_body is provided
                    "content": html_body if html_body else plain_body
                },
                "toRecipients": [
                    {
                        "emailAddress": {
                            "address": to_address
                        }
                    }
                ],
                "internetMessageHeaders": [] # For In-Reply-To and References
            },
            "saveToSentItems": "true"
        }

        # Add threading headers
        if in_reply_to_message_id:
            message_payload["message"]["internetMessageHeaders"].append({ # type: ignore
                "name": "In-Reply-To",
                "value": in_reply_to_message_id
            })
        if references_message_ids:
            message_payload["message"]["internetMessageHeaders"].append({ # type: ignore
                "name": "References",
                "value": " ".join(references_message_ids)
            })

        if attachments:
            attachments_payload = []
            for file_path in attachments:
                try:
                    with open(file_path, "rb") as f:
                        file_content = base64.b64encode(f.read()).decode("utf-8")
                    attachments_payload.append({
                        "@odata.type": "#microsoft.graph.fileAttachment",
                        "name": os.path.basename(file_path),
                        "contentType": "application/octet-stream", # Generic binary type
                        "contentBytes": file_content
                    })
                except FileNotFoundError:
                    logger.warning(f"Attachment file not found: {file_path}")
                except Exception as e:
                    logger.error(f"Error processing attachment {file_path}: {e}", exc_info=True)
            message_payload["message"]["attachments"] = attachments_payload # type: ignore

        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(send_mail_url, headers=headers, json=message_payload)
            response.raise_for_status() # Raise an exception for HTTP errors
            logger.info(f"Email sent successfully to {to_address} with subject \'{subject}\' via Outlook API.")
            return response.json() # Graph API usually returns an empty JSON for successful sendMail
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error occurred while sending email via Outlook API to {to_address}: {e}")
            if hasattr(e, 'response') and e.response.status_code == 401: # Token expired or invalid
                logger.info("Access token might be expired. Attempting to re-acquire token.")
                self.access_token = self._acquire_token() # Re-acquire token
                # In a real system, you might retry the send operation once here
            raise
        except Exception as e:
            logger.error(f"An unexpected error occurred while sending email via Outlook API to {to_address}: {e}", exc_info=True)
            raise