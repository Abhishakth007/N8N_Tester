import logging
from typing import Dict, Any, List, Optional

from config.settings import settings
from data_models.email_data import EmailMessage # Removed EmailThread import as it's not directly used
from data_models.freight_inquiry import FreightMetadata, FreightPayload
from response_generation.response_generator import ResponseGenerator
from response_generation.template_manager import TemplateManager
from response_generation.formatter import ResponseFormatter

logger = logging.getLogger(__name__)

class ResponseGenerationService:
    """
    Manages the generation of email responses based on processed freight data.
    Chooses appropriate templates and populates them with context.
    """

    def __init__(
        self,
        config: Any,
        llm_response_generator: ResponseGenerator,
        template_manager: TemplateManager,
        response_formatter: ResponseFormatter
    ):
        self._config = config 
        self._llm_response_generator = llm_response_generator
        self._template_manager = template_manager
        self._response_formatter = response_formatter
        logger.info("ResponseGenerationService initialized.")

    def generate_response(
        self,
        original_email: EmailMessage,
        processed_freight_data: FreightMetadata,
        # Removed conversation_history: List[EmailMessage]
        missing_fields: Optional[List[str]] = None,
        cost: Optional[float] = None
    ) -> str:
        """
        Generates an appropriate email response based on the processing outcome.
        """
        logger.info(f"Generating response for email from {original_email.sender}")

        template_name = "default_follow_up" # Fallback template

        if processed_freight_data.extraction_status == "partial":
            template_name = "missing_info_request"
            if not missing_fields: # Safety check
                logger.warning("Missing fields template requested but no missing_fields provided. Defaulting to empty list.")
                missing_fields = []
        elif processed_freight_data.extraction_status == "fully_extracted":
            if cost is not None and cost != "N/A":
                template_name = "freight_quote_response"
            else:
                template_name = "no_quote_found_response"

        template = self._template_manager.get_template(template_name)
        if not template:
            logger.error(f"Template '{template_name}' not found. Using generic fallback.")
            template = "Dear customer,\n\nThank you for your inquiry. We are currently processing your request and will get back to you shortly.\n\nBest regards,\n[Your Company Name]"
            
        # Prepare context for the LLM
        container_info_str = ""
        if processed_freight_data.payload and processed_freight_data.payload.container_type:
            container_info_str = f"Container Type: {', '.join(processed_freight_data.payload.container_type)}\n"

        template_context = {
            "sender_name": original_email.sender.split('@')[0],
            "subject": original_email.subject,
            "extracted_data": processed_freight_data.payload.model_dump(exclude_none=True) if processed_freight_data.payload else {},
            "missing_fields": missing_fields,
            "cost": cost,
            "query_type": processed_freight_data.query_type.value if processed_freight_data.query_type else "N/A",
            "origin_port": processed_freight_data.payload.origin_port[0] if processed_freight_data.payload and processed_freight_data.payload.origin_port else "N/A",
            "destination_port": processed_freight_data.payload.destination_port[0] if processed_freight_data.payload and processed_freight_data.payload.destination_port else "N/A",
            "cargo_type": processed_freight_data.payload.cargo_type.value if processed_freight_data.payload and processed_freight_data.payload.cargo_type else "N/A",
            "cargo_weight": processed_freight_data.payload.cargo_weight if processed_freight_data.payload else "N/A",
            "container_type": processed_freight_data.payload.container_type[0] if processed_freight_data.payload and processed_freight_data.payload.container_type else "N/A",
            "transportation_mode": processed_freight_data.payload.transportation_type.value if processed_freight_data.payload and processed_freight_data.payload.transportation_type else "N/A",
            "container_info": container_info_str,
            "payload": processed_freight_data.payload.model_dump(exclude_none=True) if processed_freight_data.payload else {},

            "enriched_port_details": processed_freight_data.payload.enriched_details.get("originPortDetails") if processed_freight_data.payload and processed_freight_data.payload.enriched_details else None,
            "enriched_commodity_details": processed_freight_data.payload.enriched_details.get("commodityDetails") if processed_freight_data.payload and processed_freight_data.payload.enriched_details else None,
            "quote_details": processed_freight_data.payload.enriched_details
        }

        # Removed _format_conversation_history and its usage as message_history is no longer available

        try:
            generated_text = self._llm_response_generator.generate_response(
                template=template,
                context=template_context,
                # Removed conversation_history=history_str
            )
            logger.info("Response generated successfully by LLM.")
        except Exception as e:
            logger.error(f"Error generating response with LLM: {e}", exc_info=True)
            generated_text = "Dear customer,\n\nWe apologize, but we are currently experiencing technical difficulties and cannot process your request at this time. Please try again later or contact us directly.\n\nBest regards,\n[Your Company Name]"

        final_response_body = self._response_formatter.format_response(
            generated_text, original_email
        )
        logger.info("Final response formatted.")
        return final_response_body

    # Removed _format_conversation_history method

    def send_followup_for_missing_fields(self, email_message: EmailMessage, missing_fields: list[str], conversation_id: str):
        if not conversation_id:
            logger.error("Missing conversation_id. Cannot send follow-up for missing fields.")
            return

        sender_name = (email_message.sender.split('@')[0] if email_message.sender else "Customer")
        subject = f"Re: {email_message.subject}" if email_message.subject and not email_message.subject.lower().startswith("re:") else email_message.subject
        subject = f"{subject} - Missing Information" if subject else "Freight Inquiry - Missing Information"

        body = f"Dear {sender_name},\n\n"
        body += "Thank you for your freight inquiry. To proceed further, we kindly request the following missing information:\n\n"
        for field in missing_fields:
            body += f"- {field.replace('_', ' ').title()}\n"
        body += "\nOnce we receive the complete details, we’ll be able to process your request promptly.\n\nBest regards,\nTariffTales Team"

        # Get proper threading info (better than email_message.message_id)
        latest_thread_info = self._context_manager.get_latest_message_info(conversation_id)
        effective_in_reply_to = latest_thread_info.get("message_id") if latest_thread_info else email_message.message_id
        effective_references = latest_thread_info.get("references") if latest_thread_info else email_message.references or []

        self._email_sender.send_email(
            to_address=email_message.sender,
            subject=subject,
            plain_body=body,
            in_reply_to_message_id=effective_in_reply_to,
            references_message_ids=effective_references,
            conversation_id=conversation_id
        )
