import logging
from typing import Dict, Any, List, Optional

from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_core.output_parsers import StrOutputParser

from llm_integration.llm_client import LLMClient

logger = logging.getLogger(__name__)

class ResponseGenerator:
    """
    Handles the generation of responses using a Large Language Model (LLM)
    based on a given template and context.
    """

    def __init__(self, llm_client: LLMClient):
        self._llm_client = llm_client
        self.llm = self._llm_client.llm

        self.response_chain = (
            {
                "template": RunnablePassthrough(),
                "context": RunnableLambda(lambda x: self._format_context(x)),
                # Removed "conversation_history": RunnablePassthrough() from this dictionary previously.
            }
            | PromptTemplate.from_template(
                """You are an intelligent freight assistant. Your task is to generate polite, professional, and clear email responses based on the provided freight inquiry details and context.

Original Inquiry Details and Context:
{context}

---
Based on the above information, please use the following email template to draft your response. Fill in any placeholders in the template with the provided context and ensure the tone is professional and helpful. Do NOT include any additional greetings or sign-offs outside of what the template implies or what is natural for an email body.

Email Template:
{template}

Your generated email body:
"""
            )
            | self.llm
            | StrOutputParser()
        )
        
        logger.info("ResponseGenerator initialized.")

    def _format_context(self, context_dict: Dict[str, Any]) -> str:
        """Formats the context dictionary into a readable string for the LLM."""
        formatted_parts = []
        for key, value in context_dict.items():
            if value is not None and value != []:
                if isinstance(value, dict):
                    formatted_parts.append(f"{key.replace('_', ' ').title()}:\n")
                    for sub_key, sub_value in value.items():
                        if sub_value is not None:
                            formatted_parts.append(f"  {sub_key.replace('_', ' ').title()}: {sub_value}")
                elif isinstance(value, list):
                    formatted_parts.append(f"{key.replace('_', ' ').title()}: {', '.join(map(str, value))}")
                else:
                    formatted_parts.append(f"{key.replace('_', ' ').title()}: {value}")
        return "\n".join(formatted_parts)

    def generate_response(
        self,
        template: str,
        context: Dict[str, Any],
        # Removed conversation_history: str from function signature previously.
    ) -> str:
        """
        Generates a response using the LLM based on the provided template and context.
        """
        try:
            response = self.response_chain.invoke({
                "template": template,
                "context": context,
                # Removed "conversation_history": conversation_history from invoke call previously.
            })
            return response
        except Exception as e:
            logger.error(f"Error generating response: {e}", exc_info=True)
            raise