import logging
from typing import Any, Optional, Dict

logger = logging.getLogger(__name__)

class TemplateManager:
    """Manages email response templates."""

    def __init__(self, config: Any):
        self._config = config
        self.templates: Dict[str, str] = self._load_templates()
        logger.info("TemplateManager initialized.")

    def _load_templates(self) -> Dict[str, str]:
        """Loads predefined email templates."""
        # In a real application, these might be loaded from files, a database, or a CMS.
        # For now, they are hardcoded.
        return {
            "missing_info_request": (
                "Dear {sender_name},\n\n"\
                "Thank you for your inquiry. To provide an accurate quote for your {query_type} shipment, "\
                "we need the following missing information: {missing_fields}.\n\n"\
                "Please reply to this email with the details.\n\n"\
                "Best regards,\n"\
                "Your Freight Team"
            ),
            "freight_quote_response": ( # Renamed from freight_quote_response to freight_quote_response
                "Dear {sender_name},\n\n"\
                "Thank you for your {query_type} inquiry. Here is your quote:\n\n"\
                "Origin: {origin_port}\n"\
                "Destination: {destination_port}\n"\
                "Cargo Type: {cargo_type}\n"\
                "Cargo Weight: {cargo_weight} kg\n"\
                "{container_info}"\
                "Rate: ${cost:.2f}\n\n"\
                "We look forward to assisting you.\n\n"\
                "Best regards,\n"\
                "Your Freight Team"
            ),
            "no_quote_found_response": ( # Renamed from no_quote_found_response to no_quote_found_response
                "Dear {sender_name},\n\n"\
                "Thank you for your {query_type} inquiry. Unfortunately, we could not find a direct quote for your request at this time. "\
                "Our team will review it and get back to you shortly.\n\n"\
                "Best regards,\n"\
                "Your Freight Team"
            ),
            "default_follow_up": ( # Added a default fallback template
                "Dear {sender_name},\n\n"\
                "Thank you for your email. We are processing your request and will get back to you soon.\n\n"\
                "Best regards,\n"\
                "Your Freight Team"
            )
        }

    def get_template(self, template_name: str) -> Optional[str]:
        """Retrieves a template by its name."""
        return self.templates.get(template_name)

if __name__ == "__main__":
    from config.settings import Settings
    # Mock settings for testing
    mock_settings = Settings()

    manager = TemplateManager(config=mock_settings)

    # Test retrieving templates
    print("Missing Info Template:")
    print(manager.get_template("missing_info_request"))

    print("\nFreight Quote Template:")
    print(manager.get_template("freight_quote_response"))

    print("\nNo Quote Found Template:")
    print(manager.get_template("no_quote_found_response"))

    print("\nDefault Follow Up Template:")
    print(manager.get_template("default_follow_up"))

    print("\nNon-existent Template:")
    print(manager.get_template("non_existent_template"))