import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from dotenv import load_dotenv
from typing import Optional

# Load environment variables from .env file
load_dotenv()

class Settings(BaseSettings):
    # General Application Settings
    APP_NAME: str = os.getenv("APP_NAME", "Agentic Email Manager")
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Email Ingestion Settings
    IMAP_SERVER: str = os.getenv("IMAP_SERVER", "imap.example.com")
    EMAIL_ACCOUNT: str = os.getenv("EMAIL_ACCOUNT", "your_email@example.com")
    EMAIL_PASSWORD: str = os.getenv("EMAIL_PASSWORD", "your_email_password")
    IMAP_PORT: int = int(os.getenv("IMAP_PORT", "993"))
    EMAIL_PROVIDER :str= os.getenv('EMAIL_PROVIDER','IMAP')
    EMAIL_CHECK_INTERVAL_SECONDS: int = int(os.getenv("EMAIL_CHECK_INTERVAL_SECONDS", os.getenv("EMAIL_FETCH_INTERVAL_SECONDS", "300")))

    # MongoDB Settings
    MONGODB_URI: str = os.getenv("MONGODB_URI", "mongodb://localhost:27017/")
    MONGODB_DB_NAME: str = os.getenv("MONGODB_DB_NAME", "freight_email_db")
    MONGODB_COLLECTION_EMAILS: str = os.getenv("MONGODB_COLLECTION_EMAILS", "emails")
    MONGODB_COLLECTION_THREADS: str = os.getenv("MONGODB_COLLECTION_THREADS", "threads")
    MONGODB_COLLECTION_FREIGHT_INQUIRIES: str = os.getenv("MONGODB_COLLECTION_FREIGHT_INQUIRIES", "freight_inquiries")

    # LLM Integration Settings
    # ADDED LLM_PROVIDER
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "google") # Assuming 'google' as default
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "your_gemini_api_key")
    OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY", None)
    ANTHROPIC_API_KEY: Optional[str] = os.getenv("ANTHROPIC_API_KEY", None)
    LLM_MODEL_NAME: str = os.getenv("LLM_MODEL_NAME", "gemini-pro")
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.2"))

    # Embedding and Classifier Settings
    EMBEDDING_MODEL_NAME: str = os.getenv("EMBEDDING_MODEL_NAME", "all-MiniLM-L6-v2")
    CLASSIFIER_SIMILARITY_THRESHOLD: float = float(os.getenv("CLASSIFIER_SIMILARITY_THRESHOLD", "0.5"))
    CLASSIFIER_TOP_K: int = int(os.getenv("CLASSIFIER_TOP_K", "2"))

    # FAISS Index and Sample Data Settings
    FAISS_INDEX_PATH: str = os.getenv("FAISS_INDEX_PATH", "./data/faiss_index.bin")
    SAMPLE_FREIGHT_DATA_PATH: str = os.getenv("SAMPLE_FREIGHT_DATA_PATH", "./data/sample_freight_data.json")
    SAMPLE_RATE_FILE_PATH: str = os.getenv("SAMPLE_RATE_FILE_PATH", "./data/sample_rate_file.xlsx")
    DATA_DIR: str = os.getenv("DATA_DIR", "./data")

    # Email Sending Settings (SMTP)
    EMAIL_SENDING_CLIENT_TYPE : str = os.getenv('EMAIL_SENDING_CLIENT_TYPE' , 'SMTP')
    SMTP_SERVER: str = os.getenv("SMTP_SERVER", "smtp.example.com")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USERNAME: str = os.getenv("SMTP_USERNAME", "your_email@example.com")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "your_email_password")
    SMTP_USE_TLS: bool = bool(os.getenv("SMTP_USE_TLS", "True").lower() == "true")
    
    # Qdrant Settings (for VectorDBClient)
    QDRANT_HOST: str = os.getenv("QDRANT_HOST", "localhost")
    QDRANT_API_KEY: Optional[str] = os.getenv("QDRANT_API_KEY", None)
    QDRANT_COLLECTION_NAME: str = os.getenv("QDRANT_COLLECTION_NAME", "freight_documents")


    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

# Create a singleton instance of settings
settings = Settings()