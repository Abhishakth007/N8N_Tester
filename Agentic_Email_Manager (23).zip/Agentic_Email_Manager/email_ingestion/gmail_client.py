import logging
from typing import List, Optional,Dict,Any
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from pydantic import EmailStr

import os
import base64
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

from data_models.email_data import EmailMessage
from config.settings import settings

logger = logging.getLogger(__name__)

# If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.send']

class GmailClient:
    """Handles Gmail API integration for fetching and sending emails."""

    def __init__(self):
        self.service = self._authenticate_gmail()
        logger.info("GmailClient initialized.")

    def _authenticate_gmail(self):
        """Authenticates with Gmail API using OAuth 2.0."""
        creds = None
        # The file token.json stores the user's access and refresh tokens, and is
        # created automatically when the authorization flow completes for the first
        # time.
        if os.path.exists('token.json'):
            creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                # Ensure credentials.json is present for the InstalledAppFlow
                if not os.path.exists('credentials.json'):
                    logger.critical("credentials.json not found. Please download it from Google Cloud Console.")
                    raise FileNotFoundError("credentials.json is required for Gmail API authentication.")

                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open('token.json', 'w') as token: # type: ignore
                token.write(creds.to_json())

        try:
            return build('gmail', 'v1', credentials=creds)
        except HttpError as error:
            logger.error(f'An error occurred during Gmail API build: {error}')
            raise

    def fetch_unread_emails(self, user_id='me') -> List[EmailMessage]:
        """Fetches unread emails from Gmail inbox."""
        fetched_emails: List[EmailMessage] = []
        try:
            # Request only unread messages
            response = self.service.users().messages().list(userId=user_id, q="is:unread").execute()
            messages = response.get('messages', [])

            if not messages:
                logger.info("No unread messages found in Gmail.")
                return []

            for msg in messages:
                msg_id = msg['id']
                full_message = self.service.users().messages().get(userId=user_id, id=msg_id, format='full').execute()
                
                # Mark message as read after fetching
                self.service.users().messages().modify(userId=user_id, id=msg_id, body={'removeLabelIds': ['UNREAD']}).execute()

                email_data = self._parse_gmail_message(full_message)
                if email_data:
                    fetched_emails.append(email_data)

        except HttpError as error:
            logger.error(f'An error occurred while fetching Gmail emails: {error}')
        except Exception as e:
            logger.error(f'An unexpected error occurred in GmailClient.fetch_unread_emails: {e}', exc_info=True)
        return fetched_emails

    def _parse_gmail_message(self, message: Dict[str, Any]) -> Optional[EmailMessage]:
        """Parses a raw Gmail message into an EmailMessage object."""
        headers = {header['name']: header['value'] for header in message['payload']['headers']}
        
        message_id = headers.get('Message-ID')
        if not message_id:
            logger.warning(f"Skipping email with no Message-ID: {message.get('id')}")
            return None

        thread_id = message.get('threadId', message_id) # Fallback to message_id if threadId is missing

        sender = headers.get('From')
        subject = headers.get('Subject')
        to_recipients = [EmailStr(addr.strip()) for addr in headers.get('To', '').split(',') if addr.strip()]
        cc_recipients = [EmailStr(addr.strip()) for addr in headers.get('Cc', '').split(',') if addr.strip()]
        bcc_recipients = [EmailStr(addr.strip()) for addr in headers.get('Bcc', '').split(',') if addr.strip()] # Added BCC
        
        in_reply_to = headers.get('In-Reply-To')
        references = headers.get('References', '').split() if headers.get('References') else []
        sent_at_str = headers.get('Date')
        
        # Parse date string
        sent_at = None
        if sent_at_str:
            try:
                from dateutil.parser import parse
                sent_at = parse(sent_at_str)
            except Exception as e:
                logger.warning(f"Could not parse date '{sent_at_str}': {e}")

        body = self._get_email_body(message['payload'])
        
        # Gmail API does not provide UID directly, but 'id' can serve a similar purpose for modification
        uid = int(message['id'], 16) if message.get('id') else None # Convert hex string ID to int if needed

        try:
            return EmailMessage(
                message_id=message_id,
                thread_id=thread_id,
                sender=sender or "unknown@example.com", # Provide a default if sender is None
                recipients=to_recipients,
                cc=cc_recipients,
                bcc=bcc_recipients, # Added BCC
                subject=subject,
                body=body,
                direction="inbound", # Assuming fetched emails are inbound
                # timestamp=sent_at or datetime.utcnow(), # 'timestamp' removed, using 'received_at' and 'sent_at'
                sent_at=sent_at or datetime.utcnow(), # Use parsed sent_at, fallback to current UTC
                received_at=datetime.utcnow(),
                in_reply_to=in_reply_to,
                references=references,
                uid=uid,
                headers=headers
            )
        except Exception as e:
            logger.error(f"Error creating EmailMessage from Gmail data: {e}", exc_info=True)
            return None

    def _get_email_body(self, payload: Dict[str, Any]) -> str:
        """Extracts the plain text body from a Gmail message payload."""
        body_content = ""
        if 'parts' in payload:
            for part in payload['parts']:
                mime_type = part.get('mimeType')
                if mime_type == 'text/plain' and 'body' in part and 'data' in part['body']:
                    body_content += base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                elif mime_type == 'text/html' and 'body' in part and 'data' in part['body']:
                    from bs4 import BeautifulSoup
                    html_content = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                    soup = BeautifulSoup(html_content, 'html.parser')
                    body_content += soup.get_text(separator='\n')
                elif 'parts' in part: # Recursively check nested parts
                    body_content += self._get_email_body(part)
        elif 'body' in payload and 'data' in payload['body']:
            body_content += base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8')
        return body_content.strip()

    def send_email(self, to_address: str, subject: str, body: str, user_id='me') -> Dict[str, Any]:
        """Sends an email using the Gmail API."""
        try:
            message = MIMEText(body)
            message['to'] = to_address
            message['from'] = user_id # 'me' or actual email address
            message['subject'] = subject

            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            send_message = {'raw': raw_message}

            message = self.service.users().messages().send(userId=user_id, body=send_message).execute()
            logger.info(f'Message Id: {message["id"]} sent successfully to {to_address}')
            return message
        except HttpError as error:
            logger.error(f'An error occurred while sending email via Gmail: {error}')
            raise
        except Exception as e:
            logger.error(f'An unexpected error occurred in GmailClient.send_email: {e}', exc_info=True)
            raise


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # --- Setup for testing (requires credentials.json and token.json) ---
    # 1. Go to Google Cloud Console: https://console.cloud.google.com/
    # 2. Create a new project or select an existing one.
    # 3. Enable the Gmail API for your project.
    # 4. Go to 'APIs & Services' -> 'Credentials'.
    # 5. Create 'OAuth client ID' credentials. Choose 'Desktop app'.
    # 6. Download the `credentials.json` file and place it in the root of your project.
    #    (e.g., freight_assistant/credentials.json)
    # 7. The first time you run this, a browser window will open for authentication.
    #    After successful authentication, a `token.json` file will be created.

    try:
        gmail_client = GmailClient()
        
        # Test fetching unread emails
        print("\n--- Fetching Unread Emails ---")
        unread_emails = gmail_client.fetch_unread_emails()
        if unread_emails:
            for email in unread_emails:
                print(f"Subject: {email.subject}")
                print(f"From: {email.sender}")
                print(f"Body (first 200 chars): {email.body[:200]}...")
                print("---")
        else:
            print("No unread emails to fetch.")

        # Test sending an email
        print("\n--- Sending Test Email ---")
        # Replace with a valid recipient email for testing
        recipient_email = settings.EMAIL_ACCOUNT # Sending to self for testing
        if recipient_email and recipient_email != "your_email@example.com":
            send_subject = "Test Email from GmailClient"
            send_body = "This is a test email sent from the GmailClient in the Agentic Email Manager project."
            try:
                sent_message = gmail_client.send_email(recipient_email, send_subject, send_body)
                print(f"Test email sent successfully. Message ID: {sent_message.get('id')}")
            except Exception as e:
                print(f"Failed to send test email: {e}")
        else:
            print("Skipping email send test: Please configure recipient_email in settings.py or directly in the script.")

    except FileNotFoundError as e:
        print(f"Setup Error: {e}. Please ensure credentials.json is in the project root.")
    except Exception as e:
        print(f"An error occurred during GmailClient test: {e}", exc_info=True)