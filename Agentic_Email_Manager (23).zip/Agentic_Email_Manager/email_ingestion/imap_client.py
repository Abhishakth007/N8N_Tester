import imaplib
from imap_tools import AND, MailBox
from bs4 import BeautifulSoup
from datetime import datetime
from typing import Optional, List
import email
import logging
from pydantic import EmailStr, TypeAdapter
import os

from config.settings import settings
from data_models.email_data import EmailMessage

EmailListAdapter = TypeAdapter(List[EmailStr])
logger = logging.getLogger(__name__)

def normalize_message_id(mid: Optional[str]) -> Optional[str]:
    return mid.strip().strip("<>").strip() if mid else None

class IMAPClient:
    def __init__(self, host: str, username: str, password: str, port: int = 993):
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.client = None

    def connect(self):
        try:
            self.client = MailBox(self.host, port=self.port)
            self.client.login(self.username, self.password)
            logger.info("IMAP Client Connected Successfully.") # Changed from print to logger.info
        except Exception as e:
            logger.error(f"IMAP Connectivity Issue: {e}", exc_info=True) # Changed from print to logger.error
            raise
        else:
            self.client.folder.set("INBOX")

    def disconnect(self):
        if self.client:
            self.client.logout()
            logger.info("IMAP Client Disconnected.") # Changed from print to logger.info

    def fetch_unread_emails(self) -> List[EmailMessage]:
        fetched_emails = []
        try:
            for msg in self.client.fetch(AND(seen=False), mark_seen=False, bulk=True):
                message_id_raw = msg.headers.get("message-id", "")
                message_id = normalize_message_id(
                    message_id_raw[0] if isinstance(message_id_raw, (list, tuple)) and message_id_raw else message_id_raw
                ) or f"generated-{msg.uid}@local"

                in_reply_to_raw = msg.headers.get("In-Reply-To")
                in_reply_to = normalize_message_id(in_reply_to_raw)

                references_raw = msg.headers.get("References")
                references = [normalize_message_id(r) for r in references_raw.split()] if references_raw else []
                
                # Ensure message_id is a string, handling cases where it might be a tuple or list
                if isinstance(message_id_raw, (list, tuple)):
                    # Join multiple Message-IDs if present, or take the first one
                    message_id = message_id_raw[0] if message_id_raw else ""
                else:
                    message_id = str(message_id_raw) # Ensure it's a string

                if not message_id:
                    message_id = f"<generated-{msg.uid}@local>"

                subject = msg.subject or None
                sender = msg.from_ or None

                recipients = EmailListAdapter.validate_python(
                    [addr.strip() for addr in msg.to]) if msg.to else []
                cc_recipients = EmailListAdapter.validate_python(
                    [addr.strip() for addr in msg.cc]) if msg.cc else []
                bcc_recipients = EmailListAdapter.validate_python(
                    [addr.strip() for addr in msg.bcc]) if msg.bcc else []

                # Body fallback
                if msg.text:
                    body = msg.text
                elif msg.html:
                    soup = BeautifulSoup(msg.html, "html.parser")
                    body = soup.get_text(separator="\n")
                else:
                    body = " "

                in_reply_to = msg.headers.get('In-Reply-To')
                references = msg.headers.get('References', '').split() if msg.headers.get('References') else []

                raw_headers = {
                    k.lower(): " ".join(v) if isinstance(v, (list, tuple)) else str(v)
                    for k, v in msg.headers.items()
                }

                x_conversation_id = raw_headers.get("x-conversation-id")

                email_message = EmailMessage(
                    message_id=message_id,
                    thread_id=in_reply_to or (references[0] if references else message_id),
                    sender=sender,
                    recipients=recipients,
                    cc=cc_recipients,
                    bcc=bcc_recipients,
                    subject=subject,
                    body=body,
                    sent_at=msg.date,
                    received_at=msg.date or datetime.utcnow(),
                    in_reply_to=in_reply_to,
                    references=references,
                    uid=msg.uid,
                    headers=raw_headers,
                    direction="inbound",
                    conversation_id=x_conversation_id or None  # <-- Inject if available
                )

                fetched_emails.append(email_message)

        except Exception as e:
            logger.exception(f"IMAPClient failed to fetch unread emails: {e}")
            return []

        return fetched_emails

    def mark_as_read(self, uids: List[int]):
        try:
            str_uids = [str(uid) for uid in uids]
            self.client.flag(str_uids, '\\Seen', True)
            logging.info(f"Marked {len(uids)} email(s) as read.")
        except Exception as e:
            logger.exception(f"Failed to mark emails as read: {e}")