# service.py
import logging
import email
from email.header import decode_header
from datetime import datetime, timezone
from typing import List, Optional, Any, Tuple , Dict

from config.settings import settings
from email_ingestion.imap_client import IMAPClient
from email_ingestion.gmail_client import GmailClient
from email_ingestion.outlook_client import OutlookClient # Placeholder
from data_models.email_data import EmailMessage

logger = logging.getLogger(__name__)

class EmailIngestionService:
    """
    Handles the ingestion of emails from various providers.
    """

    def __init__(self, config: Any):
        self._config = config
        self._client = self._initialize_email_client()
        logger.info(f"EmailIngestionService initialized for provider: {self._config.EMAIL_PROVIDER.upper()}")

    def _initialize_email_client(self):
        provider = self._config.EMAIL_PROVIDER.lower()
        if provider == "imap":
            return IMAPClient(
                host=self._config.IMAP_SERVER,
                username=self._config.EMAIL_ACCOUNT,
                password=self._config.EMAIL_PASSWORD,
                port=self._config.IMAP_PORT
            )
        elif provider == "gmail":
            # Assuming GmailClient constructor doesn't need these specific files,
            # or they are handled internally/via environment.
            # If GmailClient expects config like the IMAPClient, it should be adjusted.
            return GmailClient() 
        elif provider == "outlook":
            raise NotImplementedError("Outlook email ingestion not yet implemented.")

        else:
            raise ValueError(f"Unsupported email provider: {provider}")

    def fetch_emails(self) -> List[EmailMessage]:
        logger.info(f"Connected to {self._config.EMAIL_PROVIDER.upper()} for fetching emails.")
        try:
            email_messages = self._client.fetch_unread_emails()
            logger.info(f"Fetched {len(email_messages)} unread emails from {self._config.EMAIL_PROVIDER.upper()}.")
            return email_messages
        except Exception as e:
            logger.error(f"Error fetching emails: {e}", exc_info=True)
            return []

    def mark_email_as_read(self, email_uid: int):
        try:
            self._client.mark_as_read([email_uid])
            logger.info(f"Marked email with UID {email_uid} as read.")
        except Exception as e:
            logger.error(f"Error marking email with UID {email_uid} as read: {e}", exc_info=True)

    def disconnect(self):
        self._client.disconnect()
        logger.info(f"Disconnected from {self._config.EMAIL_PROVIDER.upper()}.")

    # The following parsing methods are moved to the respective client classes (e.g., IMAPClient, GmailClient)
    # as they are responsible for converting raw email data into EmailMessage objects.
    # Removed unused _decode_header_value, _get_email_addresses, and _parse_email_message
    # (The code for these methods is omitted here as they are no longer part of this class)

    # Example of removed methods:
    # def _decode_header_value(self, header_value: Any) -> str:
    #     # ... (logic previously here)
    #     pass

    # def _get_email_addresses(self, header_value: Optional[str]) -> List[str]:
    #     # ... (logic previously here)
    #     pass

    # def _parse_email_message(self, raw_email: Dict[str, Any]) -> EmailMessage:
    #     # ... (logic previously here)
    #     pass