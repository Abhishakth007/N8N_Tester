import logging
import json
from typing import Any, Optional, List, Dict
import os
from datetime import datetime
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables import Runnable
from data_models.email_data import EmailMessage
from config.settings import settings

from llm_integration.prompt_templates import EXTRACTION_PROMPT,PORT_INFO

logger = logging.getLogger(__name__)

class Extractor:
    """Extracts structured freight inquiry details from email bodies using LLMs.
    Uses a prompt from prompt_templates.py and integrates optional RAG context.
    """

    def __init__(self, config: Any, llm: Optional[Any] = None, retriever: Optional[Any] = None):
        self._config = config

        if llm is None:
            raise ValueError("LLM instance must be provided. Extractor does not initialize LLMs directly.")

        self._llm = llm.llm
        if retriever is None:
            from llm_integration.rag_system import RAGSystem
            self._retriever = RAGSystem()
            logger.info("RAGSystem initialized within Extractor as no retriever was provided.")
        else:
            self._retriever = retriever
        self._output_parser = JsonOutputParser()

        # JSON schema used for extraction, aligned with FreightMetadata payload schema
        # IMPORTANT: Ensure this schema matches the Pydantic models in data_models/freight_inquiry.py
        self._extraction_schema = {
            "type": "object",
            "properties": {
                "query_type": {"type": "string", "enum": ["OCEAN_FCL", "OCEAN_LCL", "AIR"]},
                "intent_resolution_stage": {"type": "string"},
                "extraction_status": {"type": "string", "enum": ["partial", "fully_extracted"]},
                "missing_mandatory_fields": {"type": "array", "items": {"type": "string"}, "nullable": True},
                "payload": {
                    "type": "object",
                    "properties": {
                        "transport_mode_group": {"type": "string", "nullable": True},
                        "transportation_mode": {"type": "string", "nullable": True},
                        "origin_port": {"type": "array", "items": {"type": "string"}, "nullable": True},
                        "destination_port": {"type": "array", "items": {"type": "string"}, "nullable": True},
                        "cargo_type": {"type": "string", "enum": ["GENERAL", "PERISHABLE", "SPECIAL", "REEFER"], "nullable": True},
                        "cargo_weight": {"type": "number", "nullable": True},
                        "container_type": {"type": "array", "items": {"type": "string"}, "nullable": True},
                        "cargo_unit_dimensions": {
                            "type": "object",
                            "properties": {
                                "length": {"type": "number", "nullable": True},
                                "breadth": {"type": "number", "nullable": True},
                                "height": {"type": "number", "nullable": True}
                            },
                            "nullable": True
                        },
                        "no_of_units": {"type": "integer", "nullable": True},
                        "shipment_date_range_from": {"type": "string", "format": "date", "nullable": True},
                        "shipment_date_range_to": {"type": "string", "format": "date", "nullable": True},
                        "incoterm": {"type": "string", "nullable": True},
                        "transportation_type": {"type": "string", "nullable": True}
                    },
                    "required": []
                }
            },
            "required": ["query_type", "intent_resolution_stage", "extraction_status", "payload"]
        }

        # Create chain: prompt -> LLM -> parser
        self._extraction_chain: Runnable = EXTRACTION_PROMPT | self._llm | self._output_parser

    def extract_freight_details(self, email_message: EmailMessage, previous_conversations: Optional[List[EmailMessage]] = None) -> Optional[Dict]:
        """Extracts structured freight inquiry details from the email body using the LLM chain."""

        if not email_message.body and not email_message.subject:
            logger.warning(f"Email {email_message.message_id} has no body or subject for extraction.")
            return None

        # Build previous context string
        if previous_conversations:
            previous_conversations.sort(key=lambda msg: msg.received_at)
            context_parts = []
            for prev_msg in previous_conversations:
                if prev_msg.message_id == email_message.message_id:
                    continue
                context_parts.append(
                    f"From: {prev_msg.sender}\n"
                    f"Subject: {prev_msg.subject}\n"
                    f"Date: {prev_msg.received_at.isoformat()}\n"
                    f"Body: {prev_msg.body}"
                )
            previous_context = "\n---\n".join(context_parts)
            if not previous_context:
                previous_context = "(No previous conversation available)"
        else:
            previous_context = "(No previous conversation available)"

        try:
            input_data = {
                "schema": json.dumps(self._extraction_schema, indent=2),
                "email_body": email_message.body,
                "email_subject": email_message.subject,
                "previous_conversation_context": previous_context,
                "Current Year": str(datetime.utcnow().year),
                "PORT_INFO": PORT_INFO

            }

            if self._retriever:
                logger.info("RAG retriever is configured. Integrating retrieved context into prompt.")
                # Use the combined email body and subject as the query for RAG
                rag_query = f"{email_message.subject or ''} {email_message.body or ''}".strip()
                if rag_query:
                    retrieved_docs = self._retriever.retrieve_documents(rag_query)
                    rag_context = "\n".join([doc.page_content for doc in retrieved_docs])
                    if not rag_context:
                        rag_context = "(No relevant RAG context found)"
                else:
                    rag_context = "(No RAG query generated from email content)"
                input_data["rag_context"] = rag_context
            else:
                input_data["rag_context"] = "(No RAG context available)"

            extracted = self._extraction_chain.invoke(input_data)
            logger.info(f"Extraction successful for email {email_message.message_id}")
            return extracted

        except Exception as e:
            logger.error(f"Extraction failed for {email_message.message_id}: {e}", exc_info=True)
            return None
    def extract_from_email(self, email_message: EmailMessage, previous_conversations: Optional[List[EmailMessage]] = None) -> Optional[Dict]:
        """Alias for extract_freight_details to match the expected interface in pipeline."""
        return self.extract_freight_details(email_message, previous_conversations)
