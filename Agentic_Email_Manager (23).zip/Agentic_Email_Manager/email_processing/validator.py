import logging
from typing import List
from data_models.freight_inquiry import FreightMetadata
from pydantic import TypeAdapter

logger = logging.getLogger(__name__)

class Validator:
    def __init__(self):
        logger.info("Validator initialized.")

    def validate_freight_data(self, extracted_data: dict, conversation_id: str) -> FreightMetadata:
        logger.info("Starting validation for extracted data: %s", extracted_data)

        if not conversation_id:
            logger.error("Missing conversation_id during validation.")
            raise ValueError("conversation_id is required and cannot be None")

        processed_extracted_data = extracted_data.copy()

        # Ensure 'missing_mandatory_fields' is a list
        if processed_extracted_data.get("missing_mandatory_fields") is None:
            processed_extracted_data["missing_mandatory_fields"] = []

        enriched_data = {
            **processed_extracted_data,
            "conversation_id": conversation_id,
        }

        try:
            validated_data = TypeAdapter(FreightMetadata).validate_python(enriched_data)
            logger.info("Extracted data successfully validated (Pydantic model).")
            return validated_data
        except Exception as e:
            logger.error("Pydantic validation failed with errors: %s", str(e))
            raise
