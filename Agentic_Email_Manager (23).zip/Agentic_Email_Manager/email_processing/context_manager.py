
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List, Union
from pydantic import EmailStr

from data_models.email_data import EmailMessage, EmailThread
from data_models.freight_inquiry import FreightMetadata
from database.database import MongoDBClient

logger = logging.getLogger(__name__)

def normalize_message_id(mid: Optional[str]) -> Optional[str]:
    return mid.strip().strip("<>").strip() if mid else None

class ContextManager:
    def __init__(self, db: MongoDBClient):
        self._freight_metadata_collection = db.get_freight_metadata_collection()
        self._conversations_collection = db.get_conversations_collection()

    def find_conversation_by_references(self, references: Union[str, List[str]]) -> Optional[str]:
        if not references:
            return None

        if isinstance(references, str):
            reference_ids = [normalize_message_id(ref) for ref in references.strip().split() if ref]
        elif isinstance(references, list):
            reference_ids = list({normalize_message_id(ref) for ref in references if ref})
        else:
            return None

        if not reference_ids:
            return None

        # Search in freight_metadata_collection for direct references
        document = self._freight_metadata_collection.find_one({
            "$or": [
                {"payload.references": {"$in": reference_ids}},
                {"last_inbound_message_id": {"$in": reference_ids}}
            ]
        })

        if document:
            logger.debug(f"Found conversation {document.get("conversation_id")} in freight_metadata via direct references.")
            return document.get("conversation_id")

        # If not found in freight_metadata, search in conversations_collection for message IDs
        thread_doc = self._conversations_collection.find_one({
            "$or": [
                {"messages.message_id": {"$in": reference_ids}},
                {"latest_message.message_id": {"$in": reference_ids}}
            ]
        })

        if thread_doc:
            logger.debug(f"Found conversation {thread_doc.get("conversation_id")} in conversations_collection via message IDs.")
            return thread_doc.get("conversation_id")

        return None

    def insert_freight_metadata(self, metadata: FreightMetadata) -> None:
        logger.info("Inserting freight metadata for conversation %s", metadata.conversation_id)
        self._freight_metadata_collection.insert_one(metadata.model_dump(by_alias=True))

    def create_conversation(self, email_message: EmailMessage) -> FreightMetadata:
        if email_message.conversation_id:
            conversation_id = normalize_message_id(email_message.conversation_id)
        elif email_message.message_id:
            conversation_id = normalize_message_id(email_message.message_id)
        else:
            conversation_id = f"generated-{uuid.uuid4()}@local"

        logger.info("New FreightMetadata conversation created with ID: %s", conversation_id)

        initial_references = list({
            normalize_message_id(ref)
            for ref in (email_message.references or []) + [email_message.message_id, conversation_id]
            if ref
        })

        new_metadata = FreightMetadata(
            conversation_id=conversation_id,
            created_at=datetime.utcnow(),
            extraction_status="partial",
            missing_mandatory_fields=[],
            payload={"references": initial_references},
            last_inbound_message_id=normalize_message_id(email_message.message_id)
        )

        self._freight_metadata_collection.insert_one(new_metadata.model_dump(by_alias=True))
        return new_metadata

    def update_conversation_thread(self, conversation_id: str, new_email_message: EmailMessage, new_conversation_summary: Optional[str] = None) -> Optional[EmailThread]:
        logger.info("Updating EmailThread for conversation ID: %s with new message: %s", conversation_id, new_email_message.message_id)
        existing_thread_doc = self._conversations_collection.find_one({"conversation_id": conversation_id})
        if not existing_thread_doc:
            logger.warning("EmailThread not found for ID %s. Cannot update.", conversation_id)
            return None

        existing_thread = EmailThread(**existing_thread_doc)
        existing_thread.messages.append(new_email_message)
        existing_thread.latest_message = new_email_message
        existing_thread.last_updated = datetime.utcnow()
        if new_conversation_summary:
            existing_thread.conversation_summary = new_conversation_summary

        update_data = existing_thread.model_dump(by_alias=True)
        update_data.pop("_id", None)

        self._conversations_collection.update_one(
            {"conversation_id": conversation_id},
            {"$set": update_data}
        )
        return existing_thread

    def get_latest_message_info(self, conversation_id: str) -> Optional[dict]:
        thread_doc = self._conversations_collection.find_one(
            {"conversation_id": conversation_id},
            {"messages.message_id": 1, "latest_message.message_id": 1}
        )

        if thread_doc:
            latest_msg_id = thread_doc.get("latest_message", {}).get("message_id")
            all_message_ids = [normalize_message_id(m.get("message_id")) for m in thread_doc.get("messages", []) if m.get("message_id")]
            if not latest_msg_id and all_message_ids:
                latest_msg_id = all_message_ids[-1]
            if conversation_id not in all_message_ids:
                all_message_ids.append(conversation_id)
            return {
                "message_id": latest_msg_id,
                "references": list(set(all_message_ids))
            }

        logger.warning("EmailThread not found for conversation %s. Falling back to FreightMetadata.", conversation_id)
        doc = self._freight_metadata_collection.find_one(
            {"conversation_id": conversation_id},
            {"payload.references": 1, "last_inbound_message_id": 1}
        )
        if doc:
            refs = [normalize_message_id(r) for r in doc.get("payload", {}).get("references", []) if r]
            last_id = normalize_message_id(doc.get("last_inbound_message_id"))
            if last_id and last_id not in refs:
                refs.append(last_id)
            if conversation_id not in refs:
                refs.append(conversation_id)
            return {
                "message_id": last_id or conversation_id,
                "references": list(set(refs))
            }
        return None

    def get_freight_metadata_document_by_id(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        logger.info(f"Fetching FreightMetadata for conversation ID: {conversation_id}")
        return self._freight_metadata_collection.find_one({"conversation_id": normalize_message_id(conversation_id)})

    def update_freight_metadata_document(self, metadata: FreightMetadata) -> None:
        logger.info(f"Updating freight metadata for conversation {metadata.conversation_id}")
        metadata_dict = metadata.model_dump(by_alias=True)
        metadata_dict.pop("_id", None)
        self._freight_metadata_collection.update_one(
            {"conversation_id": metadata.conversation_id},
            {"$set": metadata_dict}
        )

    def update_references_in_metadata(self, conversation_id: str, new_message_id: str, new_references: List[str], last_inbound_message_id: Optional[str] = None) -> None:
        if not conversation_id:
            logger.warning("No conversation_id provided for metadata update.")
            return

        logger.info(f"Updating references for FreightMetadata {conversation_id} with message {new_message_id}")
        doc = self._freight_metadata_collection.find_one(
            {"conversation_id": conversation_id},
            {"payload.references": 1}
        )
        current_refs = doc.get("payload", {}).get("references", []) if doc else []
        all_refs = [*current_refs, *new_references, new_message_id]
        normalized_refs = list({normalize_message_id(ref) for ref in all_refs if ref})

        update_fields = {
            "payload.references": normalized_refs,
            "last_updated": datetime.utcnow()
        }
        if last_inbound_message_id:
            update_fields["last_inbound_message_id"] = normalize_message_id(last_inbound_message_id)

        self._freight_metadata_collection.update_one(
            {"conversation_id": conversation_id},
            {"$set": update_fields}
        )

    def create_email_thread(self, email_message: EmailMessage, conversation_id: str) -> EmailThread:
        logger.info("Creating new EmailThread for conversation ID: %s", conversation_id)
        thread = EmailThread(
            conversation_id=conversation_id,
            messages=[email_message],
            latest_message=email_message,
            last_updated=datetime.utcnow()
        )
        self._conversations_collection.insert_one(thread.model_dump(by_alias=True))
        return thread

    def find_existing_conversation(self, email_message: EmailMessage) -> Optional[str]:
        message_ids_to_check = {
            normalize_message_id(mid)
            for mid in [email_message.in_reply_to] + (email_message.references or [])
            if mid
        }
        if not message_ids_to_check:
            return None

        query = {
            "$or": [
                {"messages.message_id": {"$in": list(message_ids_to_check)}},
                {"messages.in_reply_to": {"$in": list(message_ids_to_check)}},
                {"messages.references": {"$in": list(message_ids_to_check)}},
                {"last_message_id": {"$in": list(message_ids_to_check)}}
            ]
        }

        result = self._freight_metadata_collection.find_one(query)
        if result:
            return result.get("conversation_id")

        # Also check in the conversations collection for latest_message_id
        thread_query = {
            "$or": [
                {"messages.message_id": {"$in": list(message_ids_to_check)}},
                {"latest_message.message_id": {"$in": list(message_ids_to_check)}}
            ]
        }
        thread_result = self._conversations_collection.find_one(thread_query)
        if thread_result:
            return thread_result.get("conversation_id")

        return None




    def find_existing_conversation_by_sender_subject(self, email_message: EmailMessage) -> Optional[str]:
        logger.debug(f"Attempting to find conversation by sender: {email_message.sender} and subject: {email_message.subject}")

        # Normalize the incoming email's subject
        incoming_normalized_subject = email_message.subject.lower().replace("re:", "").replace("fwd:", "").strip()

        # Try to find in freight_metadata_collection first (for initial emails or replies where subject matches)
        # This query looks for the sender and subjects that are exact or have 'Re:'/'Fwd:' prefixes
        query_freight_metadata = {
            "$or": [
                {"messages.sender": email_message.sender, "messages.subject": email_message.subject},
                {"messages.sender": email_message.sender, "messages.subject": {"$regex": f"^Re:.*{incoming_normalized_subject}$", "$options": "i"}},
                {"messages.sender": email_message.sender, "messages.subject": {"$regex": f"^Fwd:.*{incoming_normalized_subject}$", "$options": "i"}},
            ]
        }
        result_freight_metadata = self._freight_metadata_collection.find_one(query_freight_metadata)
        if result_freight_metadata:
            logger.debug(f"Found conversation {result_freight_metadata.get("conversation_id")} in freight_metadata by sender/subject match.")
            return result_freight_metadata.get("conversation_id")

        # If not found in freight_metadata, try to find in conversations_collection (EmailThread)
        # This is crucial for replies where the subject might have changed or the latest message is an outbound one
        query_conversations = {
            "$or": [
                {"messages.sender": email_message.sender, "messages.subject": email_message.subject},
                {"messages.sender": email_message.sender, "messages.subject": {"$regex": f"^Re:.*{incoming_normalized_subject}$", "$options": "i"}},
                {"messages.sender": email_message.sender, "messages.subject": {"$regex": f"^Fwd:.*{incoming_normalized_subject}$", "$options": "i"}},
                {"latest_message.sender": email_message.sender, "latest_message.subject": email_message.subject},
                {"latest_message.sender": email_message.sender, "latest_message.subject": {"$regex": f"^Re:.*{incoming_normalized_subject}$", "$options": "i"}},
                {"latest_message.sender": email_message.sender, "latest_message.subject": {"$regex": f"^Fwd:.*{incoming_normalized_subject}$", "$options": "i"}},
            ]
        }
        result_conversations = self._conversations_collection.find_one(query_conversations)
        if result_conversations:
            logger.debug(f"Found conversation {result_conversations.get("conversation_id")} in conversations_collection by sender/subject match.")
            return result_conversations.get("conversation_id")

        # Fallback: Search for conversations where the sender is the same and the subject contains keywords
        # from the current subject. This can be more resource-intensive.
        keywords = incoming_normalized_subject.split()
        if keywords:
            keyword_regex = ".*".join(keywords) # Simple keyword matching
            query_keyword_freight_metadata = {
                "messages.sender": email_message.sender,
                "messages.subject": {"$regex": keyword_regex, "$options": "i"}
            }
            result_keyword_freight_metadata = self._freight_metadata_collection.find_one(query_keyword_freight_metadata)
            if result_keyword_freight_metadata:
                logger.debug(f"Found conversation {result_keyword_freight_metadata.get("conversation_id")} in freight_metadata by sender/keyword match.")
                return result_keyword_freight_metadata.get("conversation_id")

            query_keyword_conversations = {
                "$or": [
                    {"messages.sender": email_message.sender, "messages.subject": {"$regex": keyword_regex, "$options": "i"}},
                    {"latest_message.sender": email_message.sender, "latest_message.subject": {"$regex": keyword_regex, "$options": "i"}}
                ]
            }
            result_keyword_conversations = self._conversations_collection.find_one(query_keyword_conversations)
            if result_keyword_conversations:
                logger.debug(f"Found conversation {result_keyword_conversations.get("conversation_id")} in conversations_collection by sender/keyword match.")
                return result_keyword_conversations.get("conversation_id")

        return None



