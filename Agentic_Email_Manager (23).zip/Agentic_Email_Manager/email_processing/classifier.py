import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Any, Optional
import os
import sys
import json
import logging

# Configure logging for the module
logger = logging.getLogger(__name__)

# Add project root to sys.path for imports (consider a proper package structure for deployment)
# This path manipulation is generally better handled via PYTHONPATH or proper packaging
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from data_models.email_data import EmailMessage
# from  config.settings import settings # Settings should be imported from the main entry point or passed

class Classifier:
    """Classifies emails as \'Freight Enquiry\' or \'General Enquiry\' using FAISS and sentence embeddings.
    This classification is done without LLM dependency, relying solely on vector similarity.
    """

    def __init__(self, config: Any):
        self._config = config
        self._embedding_model: Optional[SentenceTransformer] = None
        self._faiss_index: Optional[faiss.Index] = None
        self._reference_data: List[dict] = []
        self._similarity_threshold = self._config.CLASSIFIER_SIMILARITY_THRESHOLD
        self._top_k = self._config.CLASSIFIER_TOP_K
        
        # Ensure DATA_DIR exists and is an absolute path
        self._data_dir = os.path.abspath(self._config.DATA_DIR)
        os.makedirs(self._data_dir, exist_ok=True)

        self._faiss_index_path = os.path.join(self._data_dir, 'faiss_index.bin')
        self._reference_embeddings_path = os.path.join(self._data_dir, "reference_embeddings.npy")
        self._sample_freight_data_path = os.path.abspath(self._config.SAMPLE_FREIGHT_DATA_PATH)

        try:
            self._embedding_model = SentenceTransformer(self._config.EMBEDDING_MODEL_NAME)
            logger.info(f"Loaded embedding model: {self._config.EMBEDDING_MODEL_NAME}")
        except Exception as e:
            logger.critical(f"Failed to load embedding model {self._config.EMBEDDING_MODEL_NAME}: {e}", exc_info=True)
            raise RuntimeError(f"Failed to initialize Classifier due to embedding model loading error.") from e

        self._load_reference_data()
        self._load_or_build_faiss_index()

    def _load_reference_data(self):
        """Loads reference freight inquiry data from a JSON file."""
        try:
            with open(self._sample_freight_data_path, 'r', encoding='utf-8') as f:
                self._reference_data = json.load(f)
                logger.info(f"Loaded {len(self._reference_data)} reference freight samples from {self._sample_freight_data_path}")
        except FileNotFoundError as e:
            logger.critical(f"Reference data file not found at {self._sample_freight_data_path}: {e}", exc_info=True)
            raise FileNotFoundError(f"Required reference data file missing: {self._sample_freight_data_path}") from e
        except json.JSONDecodeError as e:
            logger.critical(f"Error decoding JSON from reference data file {self._sample_freight_data_path}: {e}", exc_info=True)
            raise ValueError(f"Malformed JSON in reference data file: {self._sample_freight_data_path}") from e
        except Exception as e:
            logger.critical(f"An unexpected error occurred while loading reference data from {self._sample_freight_data_path}: {e}", exc_info=True)
            raise RuntimeError(f"Failed to load reference data: {e}") from e

    def _normalize_embeddings(self, embeddings: np.ndarray) -> np.ndarray:
        """Normalizes embeddings to unit vectors for cosine similarity calculation."""
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        # Avoid division by zero for zero vectors
        norms[norms == 0] = 1e-12 
        return embeddings / norms
    def _create_embeddings(self, texts: List[str]) -> np.ndarray:
        """Generates embeddings for a list of texts using the configured model."""
        if not self._embedding_model:
            raise RuntimeError("Embedding model not initialized.")
        logger.info(f"Creating embeddings for {len(texts)} texts.")
        try:
            embeddings = self._embedding_model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
            embeddings = self._normalize_embeddings(embeddings)
            logger.info("Embeddings created successfully.")
            return embeddings
        except Exception as e:
            logger.error(f"Error creating embeddings: {e}", exc_info=True)
            raise RuntimeError(f"Failed to create embeddings: {e}") from e

    def _load_or_build_faiss_index(self):
        """Loads an existing FAISS index or builds a new one from reference data."""
        if (os.path.exists(self._faiss_index_path) and 
            os.path.exists(self._reference_embeddings_path) and
            os.path.getsize(self._faiss_index_path) > 0 and
            os.path.getsize(self._reference_embeddings_path) > 0):
            try:
                logger.info("Attempting to load existing FAISS index and reference embeddings...")
                self._faiss_index = faiss.read_index(self._faiss_index_path)
                # Optionally, load reference embeddings if needed for other operations
                # self._reference_embeddings = np.load(self._reference_embeddings_path)
                logger.info("FAISS index loaded successfully.")
                return
            except Exception as e:
                logger.warning(f"Failed to load existing FAISS index or embeddings ({e}). Rebuilding...", exc_info=True)
        
        logger.info("FAISS index or reference not found or corrupted. Building new one...")
        reference_texts = [sample.get("email_body", "") for sample in self._reference_data if sample.get("email_body")]
        if not reference_texts:
            logger.error("No valid reference texts found to build FAISS index.")
            raise ValueError("No reference text found to build Index File")
        
        try:
            reference_embeddings = self._create_embeddings(reference_texts)
            np.save(self._reference_embeddings_path, reference_embeddings)
            
            dimension = reference_embeddings.shape[1]
            self._faiss_index = faiss.IndexFlatIP(dimension)  # Use Inner Product for cosine similarity
            self._faiss_index.add(reference_embeddings)
            faiss.write_index(self._faiss_index, self._faiss_index_path)
            logger.info("FAISS index built and saved successfully.")
        except Exception as e:
            logger.critical(f"Failed to build or save FAISS index: {e}", exc_info=True)
            raise RuntimeError(f"Failed to build FAISS index: {e}") from e

    def classify_email(self, email_message: EmailMessage) -> str:
        """Classifies an email message as \'Freight Enquiry\' or \'General Enquiry\'.
        This method uses FAISS index for classification and does NOT depend on LLM.
        """
        if not self._faiss_index:
            logger.error("FAISS index not initialized. Cannot classify email.")
            raise RuntimeError("FAISS index not initialized, cannot classify emails")

        email_content = email_message.body or email_message.subject
        if not email_content or not email_content.strip():
            logger.warning(f"Email {email_message.message_id} has no substantial content for classification. Returning \'UNKNOWN\'.")
            return "UNKNOWN"

        try:
            query_embedding = self._create_embeddings([email_content])
            
            similarities, indices = self._faiss_index.search(query_embedding, self._top_k)
            closest_similarity = similarities[0][0]

            logger.info(f"Email {email_message.message_id} - Closest Cosine Similarity: {closest_similarity:.4f}, Threshold: {self._similarity_threshold:.4f}")
            if closest_similarity >= self._similarity_threshold:
                return "Freight Enquiry"
            else:
                return "General Enquiry"
        except Exception as e:
            logger.error(f"Error classifying email {email_message.message_id}: {e}", exc_info=True)
            return "ERROR_CLASSIFYING"


# The __main__ block is commented out for production code.
# It should be used for testing/development purposes only.
if __name__ == "__main__":
    import os
    from datetime import datetime
    from data_models.email_data import EmailMessage # Import EmailMessage for the test block
    from config.settings import Settings # Import Settings for mock

    # Setup basic logging for standalone execution
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Mock settings for Classifier (should come from config.settings in real app)
    class MockSettings(Settings): # Inherit from Settings to get all defaults
        # Override specific settings for mock if necessary
        EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
        CLASSIFIER_SIMILARITY_THRESHOLD = 0.6  # Cosine similarity threshold (0 to 1)
        CLASSIFIER_TOP_K = 1
        # DATA_DIR and SAMPLE_FREIGHT_DATA_PATH will be inherited, ensure they are correct for testing
        # For this test, ensure DATA_DIR is relative to this script for the dummy data creation
        DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "data")
        SAMPLE_FREIGHT_DATA_PATH = os.path.join(DATA_DIR, "sample_freight_data.json")

    # Ensure data directory exists
    os.makedirs(MockSettings.DATA_DIR, exist_ok=True)

    # Create a dummy sample_freight_data.json if it doesn't exist for testing
    dummy_data = [
        {"email_body": "I need a quote for shipping a container from Shanghai to Los Angeles.", "type": "freight_inquiry"},
        {"email_body": "Please provide a quote for air cargo from New York to London, 100kg.", "type": "freight_inquiry"},
        {"email_body": "General inquiry about your services.", "type": "general_inquiry"},
        {"email_body": "Can you help with customs clearance for my shipment?", "type": "freight_inquiry"},
        {"email_body": "What are your operating hours?", "type": "general_inquiry"},
        {"email_body": "I want to book an FCL shipment from Busan to Seattle.", "type": "freight_inquiry"},
        {"email_body": "Looking for LCL rates for 200kg from Singapore to Sydney.", "type": "freight_inquiry"},
    ]

    if not os.path.exists(MockSettings.SAMPLE_FREIGHT_DATA_PATH):
        with open(MockSettings.SAMPLE_FREIGHT_DATA_PATH, "w", encoding="utf-8") as f:
            json.dump(dummy_data, f, indent=4)
        logger.info(f"Created dummy sample_freight_data.json at {MockSettings.SAMPLE_FREIGHT_DATA_PATH}")

    mock_settings = MockSettings()
    try:
        classifier = Classifier(config=mock_settings)

        # Test emails
        email1 = EmailMessage(
            message_id="<email1@example.com>",
            sender="test@example.com",
            recipients=["info@example.com"],
            subject="Quote for ocean freight",
            body="I need a quote for a 20ft container from Shanghai to Rotterdam.",
            direction="inbound",
            timestamp=datetime.now(),
            sent_at=datetime.now(), # Added for consistency with new EmailMessage
            received_at=datetime.utcnow() # Added for consistency with new EmailMessage
        )
        email2 = EmailMessage(
            message_id="<email2@example.com>",
            sender="test2@example.com",
            recipients=["info@example.com"],
            subject="General question",
            body="How can I contact customer support?",
            direction="inbound",
            timestamp=datetime.now(),
            sent_at=datetime.now(),
            received_at=datetime.utcnow()
        )
        email3 = EmailMessage(
            message_id="<email3@example.com>",
            sender="test3@example.com",
            recipients=["info@example.com"],
            subject="Air cargo rates",
            body="Looking for rates for air cargo from JFK to LHR, 500kg.",
            direction="inbound",
            timestamp=datetime.now(),
            sent_at=datetime.now(),
            received_at=datetime.utcnow()
        )
        email4 = EmailMessage(
            message_id="<email4@example.com>",
            sender="test4@example.com",
            recipients=["info@example.com"],
            subject="Empty email",
            body="",
            direction="inbound",
            timestamp=datetime.now(),
            sent_at=datetime.now(),
            received_at=datetime.utcnow()
        )

        print(f"Email 1 classification: {classifier.classify_email(email1)}")
        print(f"Email 2 classification: {classifier.classify_email(email2)}")
        print(f"Email 3 classification: {classifier.classify_email(email3)}")
        print(f"Email 4 classification: {classifier.classify_email(email4)}")

    except Exception as e:
        logger.error(f"An error occurred during Classifier test: {e}", exc_info=True)