import logging
import pandas as pd
from typing import Dict, Any, Optional, List

from config.settings import settings
from database.database import MongoDBClient # Corrected import path
from data_models.common import InquiryType
from data_models.freight_inquiry import FreightMetadata, FreightPayload # Import FreightMetadata and FreightPayload

logger = logging.getLogger(__name__)

class DataLookup:
    """Handles data lookups from various sources, including Excel files and MongoDB.
    Designed to be extensible for future API integrations.
    """

    def __init__(self, config: Any, mongo_client: MongoDBClient):
        self._config = config
        self._mongo_client = mongo_client
        self._rate_data: Dict[str, pd.DataFrame] = {}
        self._load_rate_data_from_excel()
        logger.info("DataLookup service initialized.")

    def _load_rate_data_from_excel(self):
        """Loads rate data from the specified Excel file, handling multiple sheets.
        Each sheet is loaded into a separate DataFrame and stored in a dictionary.
        """
        rate_file_path = self._config.SAMPLE_RATE_FILE_PATH
        try:
            # Read all sheets from the Excel file
            xls = pd.ExcelFile(rate_file_path)
            for sheet_name in xls.sheet_names:
                self._rate_data[sheet_name] = pd.read_excel(xls, sheet_name=sheet_name)
                logger.info(f"Successfully loaded sheet \'{sheet_name}\' from {rate_file_path}")
            logger.info(f"All sheets loaded from {rate_file_path}")
        except FileNotFoundError:
            logger.critical(f"Rate file not found at {rate_file_path}. Please ensure it exists.")
            raise FileNotFoundError(f"Rate file not found: {rate_file_path}")
        except Exception as e:
            logger.critical(f"Error loading rate data from Excel: {e}", exc_info=True)
            raise RuntimeError(f"Failed to load rate data from Excel: {e}")

    def get_rate(self, inquiry_type: InquiryType, query_params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Retrieves a rate based on inquiry type and query parameters from the loaded Excel data.

        Args:
            inquiry_type (InquiryType): The type of inquiry (OCEAN_FCL, OCEAN_LCL, AIR).
            query_params (Dict[str, Any]): Dictionary containing parameters for rate lookup.

        Returns:
            Optional[Dict[str, Any]]: Matching rate details, or None if no rate is found.
        """
        sheet_name = inquiry_type.value # Use InquiryType enum value as sheet name
        if sheet_name not in self._rate_data:
            logger.warning(f"Rate data for inquiry type \'{sheet_name}\' not loaded. Cannot retrieve rate.")
            return None

        df = self._rate_data[sheet_name].copy()

        try:
            # Apply filters based on query_params
            for key, value in query_params.items():
                if key in df.columns:
                    # Convert both to string for robust comparison for simplicity in demo
                    # In production, consider type-aware comparisons (e.g., numeric for numbers)
                    df = df[df[key].astype(str) == str(value)]
                else:
                    logger.debug(f"Query parameter \'{key}\' not found in \'{sheet_name}\' sheet columns. Skipping filter.")

            if not df.empty:
                # Return the first matching rate. Adjust logic for multiple matches.
                return df.iloc[0].to_dict()
            else:
                logger.info(f"No rate found for query: {query_params} in sheet \'{sheet_name}\'.")
                return None
        except Exception as e:
            logger.error(f"Error during rate lookup for \'{sheet_name}\' with query {query_params}: {e}", exc_info=True)
            return None

    def get_port_details(self, port_code: str) -> Optional[Dict[str, Any]]:
        """Retrieves port details from MongoDB.

        Args:
            port_code (str): The code of the port (e.g., "USNYC").

        Returns:
            Optional[Dict[str, Any]]: Port details, or None if not found.
        """
        try:
            # Assuming a 'ports' collection in MongoDB and lookup by 'code'
            port_details = self._mongo_client.find_one("ports", {"code": port_code})
            if port_details:
                logger.debug(f"Found port details for code {port_code}")
            else:
                logger.info(f"No port details found for code {port_code}")
            return port_details
        except Exception as e:
            logger.error(f"Error retrieving port details for code {port_code}: {e}", exc_info=True)
            return None

    def get_commodity_details(self, commodity_name: str) -> Optional[Dict[str, Any]]:
        """Retrieves commodity details from MongoDB.

        Args:
            commodity_name (str): The name of the commodity.

        Returns:
            Optional[Dict[str, Any]]: Commodity details, or None if not found.
        """
        try:
            # Assuming a 'commodities' collection in MongoDB and lookup by 'name'
            commodity_details = self._mongo_client.find_one("commodities", {"name": commodity_name})
            if commodity_details:
                logger.debug(f"Found commodity details for name {commodity_name}")
            else:
                logger.info(f"No commodity details found for name {commodity_name}")
            return commodity_details
        except Exception as e:
            logger.error(f"Error retrieving commodity details for name {commodity_name}: {e}", exc_info=True)
            return None

    def process_extracted_data(self, freight_metadata: FreightMetadata) -> FreightMetadata:
        """Processes extracted data by performing necessary lookups and enrichments.

        This method acts as an orchestration point for various data lookups.
        It should be expanded to include all necessary lookups based on the
        `extracted_data` structure and the requirements for generating a quote.

        Args:
            freight_metadata (FreightMetadata): The validated extracted freight data.

        Returns:
            FreightMetadata: Enriched data with lookup results.
        """
        # Create a mutable copy or work directly on the object if it's safe
        enriched_freight_metadata = freight_metadata.model_copy(deep=True) # Use model_copy for Pydantic v2
        payload = enriched_freight_metadata.payload

        if payload is None:
            logger.warning("No payload found in freight_metadata for processing. Returning original metadata.")
            return freight_metadata

        # Initialize enriched_details if it's None
        if payload.enriched_details is None:
            payload.enriched_details = {}

        # Lookup Origin and Destination Port Names/Codes
        # Assuming origin_port and destination_port are lists of strings (codes)
        if payload.origin_port:
            for port_code in payload.origin_port: # Iterate through all ports if multiple
                port_details = self.get_port_details(port_code)
                if port_details:
                    # Append or overwrite, depending on desired behavior for multiple ports
                    payload.enriched_details["originPortName"] = port_details.get("name", "N/A")
                    payload.enriched_details["originPortCode"] = port_details.get("code", "N/A")
                    break # Assuming we only need details for the first valid origin port for now

        if payload.destination_port:
            for port_code in payload.destination_port: # Iterate through all ports if multiple
                port_details = self.get_port_details(port_code)
                if port_details:
                    # Append or overwrite
                    payload.enriched_details["destinationPortName"] = port_details.get("name", "N/A")
                    payload.enriched_details["destinationPortCode"] = port_details.get("code", "N/A")
                    break # Assuming we only need details for the first valid destination port for now

        # Lookup Commodity Name
        if payload.cargo_type: # Assuming cargo_type enum value can be used for lookup
            commodity_name = payload.cargo_type.value # Get string value from enum
            commodity_details = self.get_commodity_details(commodity_name)
            if commodity_details:
                payload.enriched_details["Commodity_Name"] = commodity_details.get("name", "N/A")


        # Rate Lookup based on InquiryType (now query_type at top level of FreightMetadata)
        inquiry_type = enriched_freight_metadata.query_type
        rate_query_params = {}

        if inquiry_type == InquiryType.OCEAN_FCL:
            # Accessing from payload and enriched_details if available
            rate_query_params["OriginPortId"] = payload.origin_port[0] if payload.origin_port else None
            rate_query_params["DestinationPortId"] = payload.destination_port[0] if payload.destination_port else None
            if payload.container_type:
                rate_query_params["ContainerSize"] = payload.container_type[0] # Take first container type
            rate_query_params["CargoWeight"] = payload.cargo_weight # Add cargo weight to query

        elif inquiry_type == InquiryType.OCEAN_LCL:
            rate_query_params["OriginPortId"] = payload.origin_port[0] if payload.origin_port else None
            rate_query_params["DestinationPortId"] = payload.destination_port[0] if payload.destination_port else None
            rate_query_params["CargoWeight"] = payload.cargo_weight
            # Assume dimensions are available if query_type is LCL
            if payload.cargo_unit_dimensions:
                rate_query_params["Length"] = payload.cargo_unit_dimensions.length
                rate_query_params["Breadth"] = payload.cargo_unit_dimensions.breadth
                rate_query_params["Height"] = payload.cargo_unit_dimensions.height
            if payload.no_of_units is not None:
                rate_query_params["NoOfUnits"] = payload.no_of_units


        elif inquiry_type == InquiryType.AIR:
            rate_query_params["OriginPortId"] = payload.origin_port[0] if payload.origin_port else None
            rate_query_params["DestinationPortId"] = payload.destination_port[0] if payload.destination_port else None
            rate_query_params["CargoWeight"] = payload.cargo_weight
            if payload.cargo_unit_dimensions:
                rate_query_params["Length"] = payload.cargo_unit_dimensions.length
                rate_query_params["Breadth"] = payload.cargo_unit_dimensions.breadth
                rate_query_params["Height"] = payload.cargo_unit_dimensions.height
            if payload.no_of_units is not None:
                rate_query_params["NoOfUnits"] = payload.no_of_units


        if inquiry_type: # Only attempt rate lookup if query_type is determined
            found_rate = self.get_rate(inquiry_type, rate_query_params)
            if found_rate:
                # Add calculatedRate and rateDetails to the payload's enriched_details or directly to payload
                payload.enriched_details["calculatedRate"] = found_rate.get("Price")
                payload.enriched_details["rateDetails"] = found_rate
            else:
                payload.enriched_details["calculatedRate"] = "N/A"
                payload.enriched_details["rateDetails"] = {"message": f"No direct rate found in Excel for {inquiry_type.value} with query {rate_query_params}"}

        return enriched_freight_metadata

    @property
    def mongo_client(self):
        return self._mongo_client