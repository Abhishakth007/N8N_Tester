import logging
from data_models.email_data import EmailMessage
from data_models.freight_inquiry import FreightMetadata
from email_processing.context_manager import ContextManager
from email_processing.classifier import Classifier
from email_processing.extractor import Extractor
from email_processing.validator import Validator
from response_generation.service import ResponseGenerationService
from email_sending.service import EmailSendingService
from typing import Optional
from data_models.email_data import EmailThread  # Imported for EmailThread type hinting

logger = logging.getLogger(__name__)

def normalize_message_id(mid: Optional[str]) -> Optional[str]:
    return mid.strip().strip("<>").strip() if mid else None


class EmailProcessingService:
    def __init__(
        self,
        context_manager: ContextManager,
        classifier: Classifier,
        extractor: Extractor,
        validator: Validator,
        response_generator: ResponseGenerationService,
        email_sender: EmailSendingService
    ):
        self._context_manager = context_manager
        self._classifier = classifier
        self._extractor = extractor
        self._validator = validator
        self._response_generator = response_generator
        self._email_sender = email_sender
        logger.info("EmailProcessingService initialized.")


    def process_email(self, email_message: EmailMessage):
        logger.info(f"Starting processing for email: Message ID={email_message.message_id}, Subject='{email_message.subject}'")

        conversation_id_for_processing = None
        current_freight_metadata = None
        current_email_thread = None
        existing_freight_metadata_doc = None

        # Normalize message IDs upfront
        email_message.message_id = normalize_message_id(email_message.message_id)
        email_message.in_reply_to = normalize_message_id(email_message.in_reply_to)
        email_message.references = [normalize_message_id(ref) for ref in (email_message.references or [])]

        if email_message.conversation_id:
            email_message.conversation_id = normalize_message_id(email_message.conversation_id)
            logger.info(f"Email includes X-Conversation-ID header: {email_message.conversation_id}")
            conversation_id_for_processing = email_message.conversation_id
            existing_freight_metadata_doc = self._context_manager.get_freight_metadata_document_by_id(conversation_id_for_processing)
            if existing_freight_metadata_doc:
                current_freight_metadata = FreightMetadata(**existing_freight_metadata_doc)
                logger.info(f"Resolved via header. Found metadata for conversation {conversation_id_for_processing}.")
                self._context_manager.update_references_in_metadata(
                    conversation_id=conversation_id_for_processing,
                    new_message_id=email_message.message_id,
                    new_references=email_message.references,
                    last_inbound_message_id=email_message.message_id
                )
                current_freight_metadata.last_inbound_message_id = email_message.message_id
                current_email_thread = self._context_manager.update_conversation_thread(
                    conversation_id=conversation_id_for_processing,
                    new_email_message=email_message
                )
                if not current_email_thread:
                    current_email_thread = self._context_manager.create_email_thread(email_message, conversation_id_for_processing)
            else:
                logger.warning(f"Conversation ID {conversation_id_for_processing} from header not found in DB.")
                conversation_id_for_processing = None

        if not conversation_id_for_processing:
            potential_linking_ids = list(set(filter(None, [email_message.in_reply_to] + email_message.references)))
            if potential_linking_ids:
                logger.debug(f"Trying to resolve conversation from message headers: {potential_linking_ids}")
                found_id = self._context_manager.find_conversation_by_references(potential_linking_ids)
                if found_id:
                    existing_freight_metadata_doc = self._context_manager.get_freight_metadata_document_by_id(found_id)
                    if existing_freight_metadata_doc:
                        current_freight_metadata = FreightMetadata(**existing_freight_metadata_doc)
                        conversation_id_for_processing = current_freight_metadata.conversation_id
                        email_message.conversation_id = conversation_id_for_processing
                        logger.info(f"Resolved via references. Found metadata for conversation {conversation_id_for_processing}.")
                        self._context_manager.update_references_in_metadata(
                            conversation_id=conversation_id_for_processing,
                            new_message_id=email_message.message_id,
                            new_references=potential_linking_ids,
                            last_inbound_message_id=email_message.message_id
                        )
                        current_freight_metadata.last_inbound_message_id = email_message.message_id
                        current_email_thread = self._context_manager.update_conversation_thread(
                            conversation_id=conversation_id_for_processing,
                            new_email_message=email_message
                        )
                        if not current_email_thread:
                            current_email_thread = self._context_manager.create_email_thread(email_message, conversation_id_for_processing)

        # Fallback 1: Search by sender and subject pattern if no conversation found via references
        if not conversation_id_for_processing:
            logger.debug(f"Attempting fallback search by sender and subject: {email_message.sender}, {email_message.subject}")
            conversation = self._context_manager.find_existing_conversation_by_sender_subject(email_message)
            if conversation:
                conversation_id_for_processing = conversation
                existing_freight_metadata_doc = self._context_manager.get_freight_metadata_document_by_id(conversation_id_for_processing)
                if existing_freight_metadata_doc:
                    current_freight_metadata = FreightMetadata(**existing_freight_metadata_doc)
                    email_message.conversation_id = conversation_id_for_processing
                    logger.info(f"Resolved via sender/subject fallback. Found metadata for conversation {conversation_id_for_processing}.")
                    self._context_manager.update_references_in_metadata(
                        conversation_id=conversation_id_for_processing,
                        new_message_id=email_message.message_id,
                        new_references=email_message.references or [],
                        last_inbound_message_id=email_message.message_id
                    )
                    current_freight_metadata.last_inbound_message_id = email_message.message_id
                    current_email_thread = self._context_manager.update_conversation_thread(
                        conversation_id=conversation_id_for_processing,
                        new_email_message=email_message
                    )
                    if not current_email_thread:
                        current_email_thread = self._context_manager.create_email_thread(email_message, conversation_id_for_processing)

        # Fallback 2: Original fallback method (less specific, relies on message IDs)
        if not conversation_id_for_processing:
            logger.debug(f"Attempting original fallback search for email: {email_message.message_id}")
            conversation = self._context_manager.find_existing_conversation(email_message)
            if conversation:
                conversation_id_for_processing = conversation
                existing_freight_metadata_doc = self._context_manager.get_freight_metadata_document_by_id(conversation_id_for_processing)
                if existing_freight_metadata_doc:
                    current_freight_metadata = FreightMetadata(**existing_freight_metadata_doc)
                    email_message.conversation_id = conversation_id_for_processing
                    logger.info(f"Resolved via original fallback. Found metadata for conversation {conversation_id_for_processing}.")
                    self._context_manager.update_references_in_metadata(
                        conversation_id=conversation_id_for_processing,
                        new_message_id=email_message.message_id,
                        new_references=email_message.references or [],
                        last_inbound_message_id=email_message.message_id
                    )
                    current_freight_metadata.last_inbound_message_id = email_message.message_id
                    current_email_thread = self._context_manager.update_conversation_thread(
                        conversation_id=conversation_id_for_processing,
                        new_email_message=email_message
                    )
                    if not current_email_thread:
                        current_email_thread = self._context_manager.create_email_thread(email_message, conversation_id_for_processing)

        # Final fallback: create a new conversation
        if not conversation_id_for_processing:
            new_conversation_metadata = self._context_manager.create_conversation(email_message)
            current_freight_metadata = new_conversation_metadata
            conversation_id_for_processing = new_conversation_metadata.conversation_id
            email_message.conversation_id = conversation_id_for_processing  # Ensure conversation_id is set on the email_message
            current_freight_metadata.last_inbound_message_id = email_message.message_id
            current_email_thread = self._context_manager.create_email_thread(email_message, conversation_id_for_processing)
            intent_stage = self._classifier.classify_email(email_message)
            email_message.intent_resolution_stage = intent_stage
            current_freight_metadata.intent_resolution_stage = intent_stage
            logger.info(f"Created new FreightMetadata conversation {conversation_id_for_processing} for email {email_message.message_id}.")

        extracted_data_dict = self._extractor.extract_from_email(email_message)
        validated_freight_metadata_instance = self._validator.validate_freight_data(
            extracted_data_dict,
            conversation_id=conversation_id_for_processing
        )

        current_freight_metadata.query_type = validated_freight_metadata_instance.query_type
        current_freight_metadata.extraction_status = validated_freight_metadata_instance.extraction_status
        current_freight_metadata.missing_mandatory_fields = validated_freight_metadata_instance.missing_mandatory_fields
        current_freight_metadata.payload = validated_freight_metadata_instance.payload
        self._context_manager.update_freight_metadata_document(current_freight_metadata)

        if current_freight_metadata.extraction_status == "partial":
            response_text = self._response_generator.generate_response(
                original_email=email_message,
                processed_freight_data=current_freight_metadata,
                missing_fields=current_freight_metadata.missing_mandatory_fields
            )
        else:
            response_text = self._response_generator.generate_response(
                original_email=email_message,
                processed_freight_data=current_freight_metadata,
            )

        latest_thread_info = self._context_manager.get_latest_message_info(conversation_id_for_processing)
        effective_in_reply_to = latest_thread_info.get("message_id") if latest_thread_info else email_message.message_id
        effective_references = list(set((latest_thread_info.get("references") if latest_thread_info else []) + [effective_in_reply_to]))

        sent_email = self._email_sender.send_email(
            to_address=email_message.sender,
            subject=f"Re: {email_message.subject}",
            plain_body=response_text,
            in_reply_to_message_id=effective_in_reply_to,
            references_message_ids=effective_references,
            conversation_id=conversation_id_for_processing
        )

        if sent_email:
            logger.info(f"Response email sent and recorded for conversation {conversation_id_for_processing}.")
        else:
            logger.error(f"Response email sent to {email_message.sender} but not recorded. Threading may break.")
