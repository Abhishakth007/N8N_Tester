import logging
import pandas as pd
from typing import Dict, Any, Optional
import sys
import os
import json



sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from config.settings import settings
from database.client import MongoDBClient