import logging
from typing import List, Optional
import uuid
from qdrant_client import QdrantClient, models
from qdrant_client.http.models import Distance, VectorParams
from langchain_google_genai import GoogleGenerativeAIEmbeddings

from config.settings import settings

logger = logging.getLogger(__name__)

class VectorDBClient:
    """Client for interacting with a vector database (Qdrant)."""

    def __init__(self, host: str = settings.QDRANT_HOST, api_key: Optional[str] = settings.QDRANT_API_KEY,
                 collection_name: str = settings.QDRANT_COLLECTION_NAME,
                 embedding_model: str = "models/embedding-001"):
        self.client = QdrantClient(host=host, api_key=api_key)
        self.collection_name = collection_name
        self.embeddings = GoogleGenerativeAIEmbeddings(model=embedding_model, google_api_key=settings.GEMINI_API_KEY)
        self._ensure_collection_exists()
        logger.info(f"VectorDBClient initialized for collection: {self.collection_name}")

    def _ensure_collection_exists(self):
        """Ensures the Qdrant collection exists, creating it if necessary."""
        try:
            self.client.get_collection(collection_name=self.collection_name)
            logger.info(f"Collection \'{self.collection_name}\' already exists.")
        except Exception:
            logger.info(f"Collection \'{self.collection_name}\' not found. Creating new collection.")
            # Hardcoding size to 768 as it's common for 'models/embedding-001'
            self.client.recreate_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=768, distance=Distance.COSINE),
            )
            logger.info(f"Collection \'{self.collection_name}\' created.")

    def add_vectors(self, texts: List[str], metadatas: Optional[List[dict]] = None) -> List[str]:
        """Adds texts and their metadata to the vector database."""
        if not texts:
            return []

        try:
            vectors = self.embeddings.embed_documents(texts)
            points = []
            for i, text in enumerate(texts):
                point_id = str(uuid.uuid4()) # Generate a unique ID for each point
                payload = {"text": text}
                if metadatas and metadatas[i]:
                    payload.update(metadatas[i])
                points.append(models.PointStruct(
                    id=point_id,
                    vector=vectors[i],
                    payload=payload
                ))

            operation_info = self.client.upsert(
                collection_name=self.collection_name,
                wait=True,
                points=points
            )
            logger.info(f"Successfully added {len(texts)} vectors to {self.collection_name}. Status: {operation_info.status}")
            return [point.id for point in points]
        except Exception as e:
            logger.error(f"Error adding vectors to Qdrant: {e}", exc_info=True)
            raise

    def search_vectors(self, query_text: str, limit: int = 5) -> List[dict]:
        """Searches the vector database for similar texts."""
        try:
            query_vector = self.embeddings.embed_query(query_text)
            search_result = self.client.search(
                collection_name=self.collection_name,
                query_vector=query_vector,
                limit=limit,
                with_payload=True
            )
            results = []
            for hit in search_result:
                results.append({"text": hit.payload.get("text"), "score": hit.score, "payload": hit.payload})
            logger.info(f"Found {len(results)} similar vectors for query: \'{query_text}\'")
            return results
        except Exception as e:
            logger.error(f"Error searching vectors in Qdrant: {e}", exc_info=True)
            raise

# Singleton instance for easy access throughout the application
# This should ideally be initialized once in main and passed, or rely on explicit settings load.
# For now, it's global as per original design.
vector_db_client = VectorDBClient()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Ensure QDRANT_HOST, QDRANT_API_KEY, QDRANT_COLLECTION_NAME, and GOOGLE_API_KEY are set in your .env

    # Example Usage
    print("\n--- Initializing VectorDBClient ---")
    # This will try to connect to Qdrant and ensure the collection exists
    # vector_db_client = VectorDBClient(host="localhost", api_key=None) # For local Qdrant without API key

    sample_texts = [
        "This is a freight inquiry about FCL shipment from Shanghai to Los Angeles.",
        "I need to ship 10 cartons of electronics via air freight to London.",
        "What are the rates for LCL cargo from Hamburg to New York?",
        "Looking for a quote for a 20ft container from Busan to Rotterdam.",
        "Can you provide details on customs clearance for imports to Canada?"
    ]
    sample_metadatas = [
        {"type": "FCL", "origin": "Shanghai", "destination": "Los Angeles"},
        {"type": "AIR", "origin": "", "destination": "London"},
        {"type": "LCL", "origin": "Hamburg", "destination": "New York"},
        {"type": "FCL", "origin": "Busan", "destination": "Rotterdam"},
        {"type": "Customs", "origin": "", "destination": "Canada"}
    ]

    print("\n--- Adding sample vectors ---")
    try:
        ids = vector_db_client.add_vectors(sample_texts, sample_metadatas)
        print(f"Added vectors with IDs: {ids}")
    except Exception as e:
        print(f"Failed to add vectors: {e}")

    print("\n--- Searching for similar vectors ---")
    query = "I want to send a full container from China to USA."
    try:
        search_results = vector_db_client.search_vectors(query, limit=2)
        print(f"Search results for \'{query}\':")
        for res in search_results:
            print(f"  Score: {res["score"]:.4f}, Text: \'{res["text"]}\'")
            print(f"  Payload: {res["payload"]}")
    except Exception as e:
        print(f"Failed to search vectors: {e}")

    query_air = "Air cargo for electronics to UK."
    try:
        search_results_air = vector_db_client.search_vectors(query_air, limit=1)
        print(f"\nSearch results for \'{query_air}\':")
        for res in search_results_air:
            print(f"  Score: {res["score"]:.4f}, Text: \'{res["text"]}\'")
            print(f"  Payload: {res["payload"]}")
    except Exception as e:
        print(f"Failed to search vectors: {e}")