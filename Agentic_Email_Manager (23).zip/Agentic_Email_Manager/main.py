import time
import logging
import signal
import sys
from datetime import datetime

from config.settings import settings
from database.database import MongoDBClient
from llm_integration.llm_client import LLMClient
from email_ingestion.service import EmailIngestionService
from email_processing.service import EmailProcessingService
from email_processing.classifier import Classifier
from email_processing.context_manager import ContextManager
from email_processing.extractor import Extractor
from email_processing.validator import Validator
from email_processing.data_lookup import DataLookup
from email_sending.service import EmailSendingService
from email_sending.smtp_client import SMTPClient
from response_generation.service import ResponseGenerationService
from response_generation.response_generator import ResponseGenerator
from response_generation.template_manager import TemplateManager
from response_generation.formatter import ResponseFormatter
from utils.logging_config import setup_logging

# Configure logging at the very beginning
setup_logging()
logger = logging.getLogger(__name__)

# Flag to control the main loop
STOP_FLAG = False

def signal_handler(signum, frame):
    global STOP_FLAG
    logger.info("Signal received, initiating graceful shutdown...")
    STOP_FLAG = True

def main():
    logger.info("Starting Agentic Email Manager...")

    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    db_client = None
    try:
        # Initialize MongoDB client
        db_client = MongoDBClient(settings.MONGODB_URI, settings.MONGODB_DB_NAME)
        logger.info("MongoDB client connected successfully in main.py.")

        # Initialize LLM client
        llm_client = LLMClient(
            provider=settings.LLM_PROVIDER,
            model_name=settings.LLM_MODEL_NAME,
            temperature=settings.LLM_TEMPERATURE
        )

        # Initialize components
        context_manager = ContextManager(db_client)
        classifier = Classifier(config=settings)
        extractor = Extractor(config=settings, llm=llm_client)
        validator = Validator() # Removed config=settings as Validator.__init__ does not accept it
        data_lookup = DataLookup(config=settings, mongo_client=db_client)

        response_generator_llm = ResponseGenerator(llm_client) # Renamed to avoid confusion
        template_manager = TemplateManager(config=settings) # TemplateManager also takes config
        response_formatter = ResponseFormatter(config=settings)
        response_generation_service = ResponseGenerationService(
            config=settings,
            llm_response_generator=response_generator_llm, # Pass the actual LLM response generator
            template_manager=template_manager,
            response_formatter=response_formatter
        )


        email_sender = EmailSendingService(context_manager=context_manager)


        email_processing_service = EmailProcessingService(
                context_manager=context_manager,
                classifier=classifier,
                extractor=extractor,
                validator=validator,
                response_generator=response_generation_service,
                email_sender=email_sender
            )


        email_ingestion_service = EmailIngestionService(config=settings)

        logger.info("All services initialized successfully.")

        # Main loop
        while not STOP_FLAG:
            logger.info(f"Checking for new emails at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}...")

            # Connect email clients
            email_ingestion_service._client.connect()
            email_sender.connect()
            logger.info("Email connected successfully.")

            # Fetch and process unread emails
            unread_emails = email_ingestion_service.fetch_emails()
            for email_message in unread_emails:
                logger.info(f"Processing email: Subject='{email_message.subject}' From='{email_message.sender}'")
                email_processing_service.process_email(email_message)
                email_ingestion_service.mark_email_as_read(email_message.uid)

            # Disconnect clients
            email_ingestion_service.disconnect()
            email_sender.disconnect()
            logger.info("Email disconnected.")

            if not STOP_FLAG:
                logger.info(f"Finished email check. Waiting for {settings.EMAIL_CHECK_INTERVAL_SECONDS} seconds...")
                time.sleep(settings.EMAIL_CHECK_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        logger.info("Agentic Email Manager stopped by user (KeyboardInterrupt).")
    except Exception as e:
        logger.critical(f"An unhandled error occurred in main loop: {e}", exc_info=True)
    finally:
        if db_client:
            db_client.close()
            logger.info("MongoDB connection closed.")
        logger.info("Agentic Email Manager shut down.")
        sys.exit(0)

if __name__ == "__main__":
    main()