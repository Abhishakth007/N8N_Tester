gemini_api_key = "12aW78_po87hd_xq9i+q3i"
print("This is a safe file..nothing suspicous here.")